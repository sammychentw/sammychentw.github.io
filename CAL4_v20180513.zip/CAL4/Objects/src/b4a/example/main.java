package b4a.example;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = true;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new anywheresoftware.b4a.ShellBA(this.getApplicationContext(), null, null, "b4a.example", "b4a.example.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "b4a.example", "b4a.example.main");
        anywheresoftware.b4a.keywords.Common.ToastMessageShow("This application was developed with B4A trial version and should not be distributed.", true);
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
			if (mostCurrent == null || mostCurrent != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
		    processBA.raiseEvent(mostCurrent._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }



public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}
public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}

private static BA killProgramHelper(BA ba) {
    if (ba == null)
        return null;
    anywheresoftware.b4a.BA.SharedProcessBA sharedProcessBA = ba.sharedProcessBA;
    if (sharedProcessBA == null || sharedProcessBA.activityBA == null)
        return null;
    return sharedProcessBA.activityBA.get();
}
public static void killProgram() {
     {
            Activity __a = null;
            if (main.previousOne != null) {
				__a = main.previousOne.get();
			}
            else {
                BA ba = killProgramHelper(main.mostCurrent == null ? null : main.mostCurrent.processBA);
                if (ba != null) __a = ba.activity;
            }
            if (__a != null)
				__a.finish();}

BA.applicationContext.stopService(new android.content.Intent(BA.applicationContext, starter.class));
}
public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.PanelWrapper _panelmainmenu = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_ink_ml = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_ink_price = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_profit = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_clear = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_single_calculation = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_total_calculation = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_bottle = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_one_bottle = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittextresult = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_ink_ml = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_ink_name = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_ink_price = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_profit_name = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_profit_unit = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel_ink_ml = null;
public anywheresoftware.b4a.objects.ListViewWrapper _listview_ink_ml = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel_ink = null;
public anywheresoftware.b4a.objects.ListViewWrapper _listview_ink = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel_profit = null;
public anywheresoftware.b4a.objects.ListViewWrapper _listview_profit = null;
public static int _cnt_default_ink_ml_index = 0;
public static int _cnt_default_ink_name_index = 0;
public static int _cnt_default_profit_name_index = 0;
public static int _cnt_int_ink_ml_array_size = 0;
public static int _cnt_int_ink_array_size = 0;
public static int _cnt_int_profit_array_size = 0;
public static String[] _ary_str_ink_ml_name = null;
public static int[] _ary_int_ink_ml_value = null;
public static String[] _ary_str_ink_name = null;
public static String[] _ary_str_ink_price = null;
public static double[] _ary_dbl_ink_value = null;
public static String[] _ary_str_profit_name = null;
public static String[] _ary_str_profit_unit = null;
public static double[] _ary_dbl_profit_value = null;
public static int _int_select_ink_ml_index = 0;
public static int _int_select_ink_index = 0;
public static int _int_select_profit_index = 0;
public static int _int_bottle = 0;
public static int _int_cal_result = 0;
public b4a.example.starter _starter = null;
public static String  _activity_create(boolean _firsttime) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "activity_create"))
	return (String) Debug.delegate(mostCurrent.activityBA, "activity_create", new Object[] {_firsttime});
RDebugUtils.currentLine=131072;
 //BA.debugLineNum = 131072;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
RDebugUtils.currentLine=131074;
 //BA.debugLineNum = 131074;BA.debugLine="Activity.LoadLayout(\"1\")";
mostCurrent._activity.LoadLayout("1",mostCurrent.activityBA);
RDebugUtils.currentLine=131075;
 //BA.debugLineNum = 131075;BA.debugLine="Activity.Title = \"分裝價格計算機(墨水) V2018-05-13\"";
mostCurrent._activity.setTitle(BA.ObjectToCharSequence("分裝價格計算機(墨水) V2018-05-13"));
RDebugUtils.currentLine=131077;
 //BA.debugLineNum = 131077;BA.debugLine="ary_str_ink_ml_name(0) = \"5ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (0)] = "5ml";
RDebugUtils.currentLine=131078;
 //BA.debugLineNum = 131078;BA.debugLine="ary_str_ink_ml_name(1) = \"10ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (1)] = "10ml";
RDebugUtils.currentLine=131079;
 //BA.debugLineNum = 131079;BA.debugLine="ary_str_ink_ml_name(2) = \"3ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (2)] = "3ml";
RDebugUtils.currentLine=131080;
 //BA.debugLineNum = 131080;BA.debugLine="ary_str_ink_ml_name(3) = \"6ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (3)] = "6ml";
RDebugUtils.currentLine=131081;
 //BA.debugLineNum = 131081;BA.debugLine="ary_str_ink_ml_name(4) = \"8ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (4)] = "8ml";
RDebugUtils.currentLine=131083;
 //BA.debugLineNum = 131083;BA.debugLine="ary_int_ink_ml_value(0) = 5";
_ary_int_ink_ml_value[(int) (0)] = (int) (5);
RDebugUtils.currentLine=131084;
 //BA.debugLineNum = 131084;BA.debugLine="ary_int_ink_ml_value(1) = 10";
_ary_int_ink_ml_value[(int) (1)] = (int) (10);
RDebugUtils.currentLine=131085;
 //BA.debugLineNum = 131085;BA.debugLine="ary_int_ink_ml_value(2) = 3";
_ary_int_ink_ml_value[(int) (2)] = (int) (3);
RDebugUtils.currentLine=131086;
 //BA.debugLineNum = 131086;BA.debugLine="ary_int_ink_ml_value(3) = 6";
_ary_int_ink_ml_value[(int) (3)] = (int) (6);
RDebugUtils.currentLine=131087;
 //BA.debugLineNum = 131087;BA.debugLine="ary_int_ink_ml_value(4) = 8";
_ary_int_ink_ml_value[(int) (4)] = (int) (8);
RDebugUtils.currentLine=131089;
 //BA.debugLineNum = 131089;BA.debugLine="ary_str_ink_name(0) = \"Pilot 百樂 Iroshizuku 色彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (0)] = "Pilot 百樂 Iroshizuku 色彩墨水";
RDebugUtils.currentLine=131090;
 //BA.debugLineNum = 131090;BA.debugLine="ary_str_ink_name(1) = \"日本 KOBE INK物語 限定墨水\"";
mostCurrent._ary_str_ink_name[(int) (1)] = "日本 KOBE INK物語 限定墨水";
RDebugUtils.currentLine=131091;
 //BA.debugLineNum = 131091;BA.debugLine="ary_str_ink_name(2) = \"DIAMINE SHIMMERTASTIC 金銀粉\"";
mostCurrent._ary_str_ink_name[(int) (2)] = "DIAMINE SHIMMERTASTIC 金銀粉";
RDebugUtils.currentLine=131092;
 //BA.debugLineNum = 131092;BA.debugLine="ary_str_ink_name(3) = \"英國 DIAMINE 墨水\"";
mostCurrent._ary_str_ink_name[(int) (3)] = "英國 DIAMINE 墨水";
RDebugUtils.currentLine=131093;
 //BA.debugLineNum = 131093;BA.debugLine="ary_str_ink_name(4) = \"英國 DIAMINE 150th 墨水\"";
mostCurrent._ary_str_ink_name[(int) (4)] = "英國 DIAMINE 150th 墨水";
RDebugUtils.currentLine=131094;
 //BA.debugLineNum = 131094;BA.debugLine="ary_str_ink_name(5) = \"英國 DIAMINE 花系列、音樂家墨水\"";
mostCurrent._ary_str_ink_name[(int) (5)] = "英國 DIAMINE 花系列、音樂家墨水";
RDebugUtils.currentLine=131095;
 //BA.debugLineNum = 131095;BA.debugLine="ary_str_ink_name(6) = \"中國 壇水墨水\"";
mostCurrent._ary_str_ink_name[(int) (6)] = "中國 壇水墨水";
RDebugUtils.currentLine=131096;
 //BA.debugLineNum = 131096;BA.debugLine="ary_str_ink_name(7) = \"中國 壇水金銀粉墨水\"";
mostCurrent._ary_str_ink_name[(int) (7)] = "中國 壇水金銀粉墨水";
RDebugUtils.currentLine=131097;
 //BA.debugLineNum = 131097;BA.debugLine="ary_str_ink_name(8) = \"臺灣 醃漬物 墨水\"";
mostCurrent._ary_str_ink_name[(int) (8)] = "臺灣 醃漬物 墨水";
RDebugUtils.currentLine=131098;
 //BA.debugLineNum = 131098;BA.debugLine="ary_str_ink_name(9) = \"臺灣 臺灣人物 墨水\"";
mostCurrent._ary_str_ink_name[(int) (9)] = "臺灣 臺灣人物 墨水";
RDebugUtils.currentLine=131099;
 //BA.debugLineNum = 131099;BA.debugLine="ary_str_ink_name(10) = \"CROSS 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (10)] = "CROSS 鋼筆墨水";
RDebugUtils.currentLine=131100;
 //BA.debugLineNum = 131100;BA.debugLine="ary_str_ink_name(11) = \"ROHRER & KLINGNER 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (11)] = "ROHRER & KLINGNER 鋼筆墨水";
RDebugUtils.currentLine=131101;
 //BA.debugLineNum = 131101;BA.debugLine="ary_str_ink_name(12) = \"ROHRER & KLINGNER 蟲膠金銀墨水\"";
mostCurrent._ary_str_ink_name[(int) (12)] = "ROHRER & KLINGNER 蟲膠金銀墨水";
RDebugUtils.currentLine=131102;
 //BA.debugLineNum = 131102;BA.debugLine="ary_str_ink_name(13) = \"ROHRER & KLINGNER 蟲膠墨水\"";
mostCurrent._ary_str_ink_name[(int) (13)] = "ROHRER & KLINGNER 蟲膠墨水";
RDebugUtils.currentLine=131103;
 //BA.debugLineNum = 131103;BA.debugLine="ary_str_ink_name(14) = \"ROHRER & KLINGNER 速寫墨水\"";
mostCurrent._ary_str_ink_name[(int) (14)] = "ROHRER & KLINGNER 速寫墨水";
RDebugUtils.currentLine=131104;
 //BA.debugLineNum = 131104;BA.debugLine="ary_str_ink_name(15) = \"ROHRER & KLINGNER 防水檔案墨水\"";
mostCurrent._ary_str_ink_name[(int) (15)] = "ROHRER & KLINGNER 防水檔案墨水";
RDebugUtils.currentLine=131105;
 //BA.debugLineNum = 131105;BA.debugLine="ary_str_ink_name(16) = \"ROHRER & KLINGNER 古典沾水筆墨水";
mostCurrent._ary_str_ink_name[(int) (16)] = "ROHRER & KLINGNER 古典沾水筆墨水";
RDebugUtils.currentLine=131106;
 //BA.debugLineNum = 131106;BA.debugLine="ary_str_ink_name(17) = \"丹麥 喬治傑森 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (17)] = "丹麥 喬治傑森 鋼筆墨水";
RDebugUtils.currentLine=131107;
 //BA.debugLineNum = 131107;BA.debugLine="ary_str_ink_name(18) = \"KWZ 標準鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (18)] = "KWZ 標準鋼筆墨水";
RDebugUtils.currentLine=131108;
 //BA.debugLineNum = 131108;BA.debugLine="ary_str_ink_name(19) = \"KWZ 防水鐵膽墨水\"";
mostCurrent._ary_str_ink_name[(int) (19)] = "KWZ 防水鐵膽墨水";
RDebugUtils.currentLine=131109;
 //BA.debugLineNum = 131109;BA.debugLine="ary_str_ink_name(20) = \"Faber-Castell 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (20)] = "Faber-Castell 鋼筆墨水";
RDebugUtils.currentLine=131110;
 //BA.debugLineNum = 131110;BA.debugLine="ary_str_ink_name(21) = \"德國 Jansen 手工墨水\"";
mostCurrent._ary_str_ink_name[(int) (21)] = "德國 Jansen 手工墨水";
RDebugUtils.currentLine=131111;
 //BA.debugLineNum = 131111;BA.debugLine="ary_str_ink_name(22) = \"德國 Jansen 手工香味墨水\"";
mostCurrent._ary_str_ink_name[(int) (22)] = "德國 Jansen 手工香味墨水";
RDebugUtils.currentLine=131112;
 //BA.debugLineNum = 131112;BA.debugLine="ary_str_ink_name(23) = \"德國 Jansen 香奈兒香味墨水\"";
mostCurrent._ary_str_ink_name[(int) (23)] = "德國 Jansen 香奈兒香味墨水";
RDebugUtils.currentLine=131113;
 //BA.debugLineNum = 131113;BA.debugLine="ary_str_ink_name(24) = \"百利金 4001 墨水\"";
mostCurrent._ary_str_ink_name[(int) (24)] = "百利金 4001 墨水";
RDebugUtils.currentLine=131114;
 //BA.debugLineNum = 131114;BA.debugLine="ary_str_ink_name(25) = \"百利金 4001 碳素墨水\"";
mostCurrent._ary_str_ink_name[(int) (25)] = "百利金 4001 碳素墨水";
RDebugUtils.currentLine=131115;
 //BA.debugLineNum = 131115;BA.debugLine="ary_str_ink_name(26) = \"百利金 Edelstein 逸彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (26)] = "百利金 Edelstein 逸彩墨水";
RDebugUtils.currentLine=131116;
 //BA.debugLineNum = 131116;BA.debugLine="ary_str_ink_name(27) = \"日本白金 Classic Ink 古典墨水\"";
mostCurrent._ary_str_ink_name[(int) (27)] = "日本白金 Classic Ink 古典墨水";
RDebugUtils.currentLine=131117;
 //BA.debugLineNum = 131117;BA.debugLine="ary_str_ink_name(28) = \"日本白金 Mixable ink 混色墨水\"";
mostCurrent._ary_str_ink_name[(int) (28)] = "日本白金 Mixable ink 混色墨水";
RDebugUtils.currentLine=131118;
 //BA.debugLineNum = 131118;BA.debugLine="ary_str_ink_name(29) = \"日本白金 Mixable ink 墨水調和液\"";
mostCurrent._ary_str_ink_name[(int) (29)] = "日本白金 Mixable ink 墨水調和液";
RDebugUtils.currentLine=131119;
 //BA.debugLineNum = 131119;BA.debugLine="ary_str_ink_name(30) = \"日本白金 超微粒子防水墨水\"";
mostCurrent._ary_str_ink_name[(int) (30)] = "日本白金 超微粒子防水墨水";
RDebugUtils.currentLine=131120;
 //BA.debugLineNum = 131120;BA.debugLine="ary_str_ink_name(31) = \"日本白金 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (31)] = "日本白金 鋼筆墨水";
RDebugUtils.currentLine=131121;
 //BA.debugLineNum = 131121;BA.debugLine="ary_str_ink_name(32) = \"寫樂 jentle ink 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (32)] = "寫樂 jentle ink 鋼筆墨水";
RDebugUtils.currentLine=131122;
 //BA.debugLineNum = 131122;BA.debugLine="ary_str_ink_name(33) = \"寫樂 STORiA 防水墨水\"";
mostCurrent._ary_str_ink_name[(int) (33)] = "寫樂 STORiA 防水墨水";
RDebugUtils.currentLine=131123;
 //BA.debugLineNum = 131123;BA.debugLine="ary_str_ink_name(34) = \"寫樂 （大）四季彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (34)] = "寫樂 （大）四季彩墨水";
RDebugUtils.currentLine=131124;
 //BA.debugLineNum = 131124;BA.debugLine="ary_str_ink_name(35) = \"寫樂 （新）四季彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (35)] = "寫樂 （新）四季彩墨水";
RDebugUtils.currentLine=131125;
 //BA.debugLineNum = 131125;BA.debugLine="ary_str_ink_name(36) = \"寫樂 （新）四季織墨水\"";
mostCurrent._ary_str_ink_name[(int) (36)] = "寫樂 （新）四季織墨水";
RDebugUtils.currentLine=131126;
 //BA.debugLineNum = 131126;BA.debugLine="ary_str_ink_name(37) = \"寫樂 防水墨水\"";
mostCurrent._ary_str_ink_name[(int) (37)] = "寫樂 防水墨水";
RDebugUtils.currentLine=131127;
 //BA.debugLineNum = 131127;BA.debugLine="ary_str_ink_name(38) = \"日本 京之音墨水\"";
mostCurrent._ary_str_ink_name[(int) (38)] = "日本 京之音墨水";
RDebugUtils.currentLine=131128;
 //BA.debugLineNum = 131128;BA.debugLine="ary_str_ink_name(39) = \"日本 京彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (39)] = "日本 京彩墨水";
RDebugUtils.currentLine=131129;
 //BA.debugLineNum = 131129;BA.debugLine="ary_str_ink_name(40) = \"日本 京音京彩墨水限定色\"";
mostCurrent._ary_str_ink_name[(int) (40)] = "日本 京音京彩墨水限定色";
RDebugUtils.currentLine=131130;
 //BA.debugLineNum = 131130;BA.debugLine="ary_str_ink_name(41) = \"法國 J. Herbin 1670 墨水\"";
mostCurrent._ary_str_ink_name[(int) (41)] = "法國 J. Herbin 1670 墨水";
RDebugUtils.currentLine=131131;
 //BA.debugLineNum = 131131;BA.debugLine="ary_str_ink_name(42) = \"法國 J. Herbin 1798 墨水\"";
mostCurrent._ary_str_ink_name[(int) (42)] = "法國 J. Herbin 1798 墨水";
RDebugUtils.currentLine=131132;
 //BA.debugLineNum = 131132;BA.debugLine="ary_str_ink_name(43) = \"法國 J. Herbin 珍珠彩墨 墨水\"";
mostCurrent._ary_str_ink_name[(int) (43)] = "法國 J. Herbin 珍珠彩墨 墨水";
RDebugUtils.currentLine=131133;
 //BA.debugLineNum = 131133;BA.debugLine="ary_str_ink_name(44) = \"法國 都彭 S.T. DUPONT 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (44)] = "法國 都彭 S.T. DUPONT 鋼筆墨水";
RDebugUtils.currentLine=131134;
 //BA.debugLineNum = 131134;BA.debugLine="ary_str_ink_name(45) = \"瑞士 卡達 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (45)] = "瑞士 卡達 鋼筆墨水";
RDebugUtils.currentLine=131135;
 //BA.debugLineNum = 131135;BA.debugLine="ary_str_ink_name(46) = \"美國 Monteverde USA 核心墨水\"";
mostCurrent._ary_str_ink_name[(int) (46)] = "美國 Monteverde USA 核心墨水";
RDebugUtils.currentLine=131136;
 //BA.debugLineNum = 131136;BA.debugLine="ary_str_ink_name(47) = \"美國 Monteverde 鋼筆清洗劑\"";
mostCurrent._ary_str_ink_name[(int) (47)] = "美國 Monteverde 鋼筆清洗劑";
RDebugUtils.currentLine=131137;
 //BA.debugLineNum = 131137;BA.debugLine="ary_str_ink_name(48) = \"義大利 Aurora 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (48)] = "義大利 Aurora 鋼筆墨水";
RDebugUtils.currentLine=131138;
 //BA.debugLineNum = 131138;BA.debugLine="ary_str_ink_name(49) = \"臺灣 墨堤 墨水\"";
mostCurrent._ary_str_ink_name[(int) (49)] = "臺灣 墨堤 墨水";
RDebugUtils.currentLine=131139;
 //BA.debugLineNum = 131139;BA.debugLine="ary_str_ink_name(50) = \"臺灣 道具屋藍濃 墨水\"";
mostCurrent._ary_str_ink_name[(int) (50)] = "臺灣 道具屋藍濃 墨水";
RDebugUtils.currentLine=131140;
 //BA.debugLineNum = 131140;BA.debugLine="ary_str_ink_name(51) = \"臺灣 道具屋藍濃 限定色墨水\"";
mostCurrent._ary_str_ink_name[(int) (51)] = "臺灣 道具屋藍濃 限定色墨水";
RDebugUtils.currentLine=131141;
 //BA.debugLineNum = 131141;BA.debugLine="ary_str_ink_name(52) = \"臺灣 道具屋藍濃 防水墨水\"";
mostCurrent._ary_str_ink_name[(int) (52)] = "臺灣 道具屋藍濃 防水墨水";
RDebugUtils.currentLine=131142;
 //BA.debugLineNum = 131142;BA.debugLine="ary_str_ink_name(53) = \"英國 YARD-O-LED 墨水\"";
mostCurrent._ary_str_ink_name[(int) (53)] = "英國 YARD-O-LED 墨水";
RDebugUtils.currentLine=131143;
 //BA.debugLineNum = 131143;BA.debugLine="ary_str_ink_name(54) = \"西華 鋼筆 墨水\"";
mostCurrent._ary_str_ink_name[(int) (54)] = "西華 鋼筆 墨水";
RDebugUtils.currentLine=131145;
 //BA.debugLineNum = 131145;BA.debugLine="ary_str_ink_price(0) = \"50ML 480元\"";
mostCurrent._ary_str_ink_price[(int) (0)] = "50ML 480元";
RDebugUtils.currentLine=131146;
 //BA.debugLineNum = 131146;BA.debugLine="ary_str_ink_price(1) = \"50ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (1)] = "50ML 550元";
RDebugUtils.currentLine=131147;
 //BA.debugLineNum = 131147;BA.debugLine="ary_str_ink_price(2) = \"50ML 440元\"";
mostCurrent._ary_str_ink_price[(int) (2)] = "50ML 440元";
RDebugUtils.currentLine=131148;
 //BA.debugLineNum = 131148;BA.debugLine="ary_str_ink_price(3) = \"80ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (3)] = "80ML 300元";
RDebugUtils.currentLine=131149;
 //BA.debugLineNum = 131149;BA.debugLine="ary_str_ink_price(4) = \"40ML 325元\"";
mostCurrent._ary_str_ink_price[(int) (4)] = "40ML 325元";
RDebugUtils.currentLine=131150;
 //BA.debugLineNum = 131150;BA.debugLine="ary_str_ink_price(5) = \"30ML 270元\"";
mostCurrent._ary_str_ink_price[(int) (5)] = "30ML 270元";
RDebugUtils.currentLine=131151;
 //BA.debugLineNum = 131151;BA.debugLine="ary_str_ink_price(6) = \"60ML 200元\"";
mostCurrent._ary_str_ink_price[(int) (6)] = "60ML 200元";
RDebugUtils.currentLine=131152;
 //BA.debugLineNum = 131152;BA.debugLine="ary_str_ink_price(7) = \"60ML 220元\"";
mostCurrent._ary_str_ink_price[(int) (7)] = "60ML 220元";
RDebugUtils.currentLine=131153;
 //BA.debugLineNum = 131153;BA.debugLine="ary_str_ink_price(8) = \"15ML 220元\"";
mostCurrent._ary_str_ink_price[(int) (8)] = "15ML 220元";
RDebugUtils.currentLine=131154;
 //BA.debugLineNum = 131154;BA.debugLine="ary_str_ink_price(9) = \"30ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (9)] = "30ML 300元";
RDebugUtils.currentLine=131155;
 //BA.debugLineNum = 131155;BA.debugLine="ary_str_ink_price(10) = \"62.5ML 350元\"";
mostCurrent._ary_str_ink_price[(int) (10)] = "62.5ML 350元";
RDebugUtils.currentLine=131156;
 //BA.debugLineNum = 131156;BA.debugLine="ary_str_ink_price(11) = \"50ML 350元\"";
mostCurrent._ary_str_ink_price[(int) (11)] = "50ML 350元";
RDebugUtils.currentLine=131157;
 //BA.debugLineNum = 131157;BA.debugLine="ary_str_ink_price(12) = \"50ML 350元\"";
mostCurrent._ary_str_ink_price[(int) (12)] = "50ML 350元";
RDebugUtils.currentLine=131158;
 //BA.debugLineNum = 131158;BA.debugLine="ary_str_ink_price(13) = \"50ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (13)] = "50ML 300元";
RDebugUtils.currentLine=131159;
 //BA.debugLineNum = 131159;BA.debugLine="ary_str_ink_price(14) = \"50ML 450元\"";
mostCurrent._ary_str_ink_price[(int) (14)] = "50ML 450元";
RDebugUtils.currentLine=131160;
 //BA.debugLineNum = 131160;BA.debugLine="ary_str_ink_price(15) = \"50ML 700元\"";
mostCurrent._ary_str_ink_price[(int) (15)] = "50ML 700元";
RDebugUtils.currentLine=131161;
 //BA.debugLineNum = 131161;BA.debugLine="ary_str_ink_price(16) = \"100ML 400元\"";
mostCurrent._ary_str_ink_price[(int) (16)] = "100ML 400元";
RDebugUtils.currentLine=131162;
 //BA.debugLineNum = 131162;BA.debugLine="ary_str_ink_price(17) = \"35ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (17)] = "35ML 550元";
RDebugUtils.currentLine=131163;
 //BA.debugLineNum = 131163;BA.debugLine="ary_str_ink_price(18) = \"60ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (18)] = "60ML 550元";
RDebugUtils.currentLine=131164;
 //BA.debugLineNum = 131164;BA.debugLine="ary_str_ink_price(19) = \"60ML 600元\"";
mostCurrent._ary_str_ink_price[(int) (19)] = "60ML 600元";
RDebugUtils.currentLine=131165;
 //BA.debugLineNum = 131165;BA.debugLine="ary_str_ink_price(20) = \"75ML 960元\"";
mostCurrent._ary_str_ink_price[(int) (20)] = "75ML 960元";
RDebugUtils.currentLine=131166;
 //BA.debugLineNum = 131166;BA.debugLine="ary_str_ink_price(21) = \"35ML 450元\"";
mostCurrent._ary_str_ink_price[(int) (21)] = "35ML 450元";
RDebugUtils.currentLine=131167;
 //BA.debugLineNum = 131167;BA.debugLine="ary_str_ink_price(22) = \"35ML 500元\"";
mostCurrent._ary_str_ink_price[(int) (22)] = "35ML 500元";
RDebugUtils.currentLine=131168;
 //BA.debugLineNum = 131168;BA.debugLine="ary_str_ink_price(23) = \"35ML 650元\"";
mostCurrent._ary_str_ink_price[(int) (23)] = "35ML 650元";
RDebugUtils.currentLine=131169;
 //BA.debugLineNum = 131169;BA.debugLine="ary_str_ink_price(24) = \"62.5ML 240元\"";
mostCurrent._ary_str_ink_price[(int) (24)] = "62.5ML 240元";
RDebugUtils.currentLine=131170;
 //BA.debugLineNum = 131170;BA.debugLine="ary_str_ink_price(25) = \"30ML 240元\"";
mostCurrent._ary_str_ink_price[(int) (25)] = "30ML 240元";
RDebugUtils.currentLine=131171;
 //BA.debugLineNum = 131171;BA.debugLine="ary_str_ink_price(26) = \"50ML 490元\"";
mostCurrent._ary_str_ink_price[(int) (26)] = "50ML 490元";
RDebugUtils.currentLine=131172;
 //BA.debugLineNum = 131172;BA.debugLine="ary_str_ink_price(27) = \"60ML 630元\"";
mostCurrent._ary_str_ink_price[(int) (27)] = "60ML 630元";
RDebugUtils.currentLine=131173;
 //BA.debugLineNum = 131173;BA.debugLine="ary_str_ink_price(28) = \"60ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (28)] = "60ML 300元";
RDebugUtils.currentLine=131174;
 //BA.debugLineNum = 131174;BA.debugLine="ary_str_ink_price(29) = \"50ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (29)] = "50ML 300元";
RDebugUtils.currentLine=131175;
 //BA.debugLineNum = 131175;BA.debugLine="ary_str_ink_price(30) = \"60ML 400元\"";
mostCurrent._ary_str_ink_price[(int) (30)] = "60ML 400元";
RDebugUtils.currentLine=131176;
 //BA.debugLineNum = 131176;BA.debugLine="ary_str_ink_price(31) = \"60ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (31)] = "60ML 300元";
RDebugUtils.currentLine=131177;
 //BA.debugLineNum = 131177;BA.debugLine="ary_str_ink_price(32) = \"50ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (32)] = "50ML 300元";
RDebugUtils.currentLine=131178;
 //BA.debugLineNum = 131178;BA.debugLine="ary_str_ink_price(33) = \"30ML 450元\"";
mostCurrent._ary_str_ink_price[(int) (33)] = "30ML 450元";
RDebugUtils.currentLine=131179;
 //BA.debugLineNum = 131179;BA.debugLine="ary_str_ink_price(34) = \"50ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (34)] = "50ML 300元";
RDebugUtils.currentLine=131180;
 //BA.debugLineNum = 131180;BA.debugLine="ary_str_ink_price(35) = \"20ML 250元\"";
mostCurrent._ary_str_ink_price[(int) (35)] = "20ML 250元";
RDebugUtils.currentLine=131181;
 //BA.debugLineNum = 131181;BA.debugLine="ary_str_ink_price(36) = \"20ML 280元\"";
mostCurrent._ary_str_ink_price[(int) (36)] = "20ML 280元";
RDebugUtils.currentLine=131182;
 //BA.debugLineNum = 131182;BA.debugLine="ary_str_ink_price(37) = \"50ML 500元\"";
mostCurrent._ary_str_ink_price[(int) (37)] = "50ML 500元";
RDebugUtils.currentLine=131183;
 //BA.debugLineNum = 131183;BA.debugLine="ary_str_ink_price(38) = \"40ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (38)] = "40ML 550元";
RDebugUtils.currentLine=131184;
 //BA.debugLineNum = 131184;BA.debugLine="ary_str_ink_price(39) = \"40ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (39)] = "40ML 550元";
RDebugUtils.currentLine=131185;
 //BA.debugLineNum = 131185;BA.debugLine="ary_str_ink_price(40) = \"40ML 650元\"";
mostCurrent._ary_str_ink_price[(int) (40)] = "40ML 650元";
RDebugUtils.currentLine=131186;
 //BA.debugLineNum = 131186;BA.debugLine="ary_str_ink_price(41) = \"50ML 650元\"";
mostCurrent._ary_str_ink_price[(int) (41)] = "50ML 650元";
RDebugUtils.currentLine=131187;
 //BA.debugLineNum = 131187;BA.debugLine="ary_str_ink_price(42) = \"50ML 800元\"";
mostCurrent._ary_str_ink_price[(int) (42)] = "50ML 800元";
RDebugUtils.currentLine=131188;
 //BA.debugLineNum = 131188;BA.debugLine="ary_str_ink_price(43) = \"30ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (43)] = "30ML 300元";
RDebugUtils.currentLine=131189;
 //BA.debugLineNum = 131189;BA.debugLine="ary_str_ink_price(44) = \"50ML 600元\"";
mostCurrent._ary_str_ink_price[(int) (44)] = "50ML 600元";
RDebugUtils.currentLine=131190;
 //BA.debugLineNum = 131190;BA.debugLine="ary_str_ink_price(45) = \"50ML 945元\"";
mostCurrent._ary_str_ink_price[(int) (45)] = "50ML 945元";
RDebugUtils.currentLine=131191;
 //BA.debugLineNum = 131191;BA.debugLine="ary_str_ink_price(46) = \"90ML 368元\"";
mostCurrent._ary_str_ink_price[(int) (46)] = "90ML 368元";
RDebugUtils.currentLine=131192;
 //BA.debugLineNum = 131192;BA.debugLine="ary_str_ink_price(47) = \"480ML 576元\"";
mostCurrent._ary_str_ink_price[(int) (47)] = "480ML 576元";
RDebugUtils.currentLine=131193;
 //BA.debugLineNum = 131193;BA.debugLine="ary_str_ink_price(48) = \"45ML 360元\"";
mostCurrent._ary_str_ink_price[(int) (48)] = "45ML 360元";
RDebugUtils.currentLine=131194;
 //BA.debugLineNum = 131194;BA.debugLine="ary_str_ink_price(49) = \"20ML 220元\"";
mostCurrent._ary_str_ink_price[(int) (49)] = "20ML 220元";
RDebugUtils.currentLine=131195;
 //BA.debugLineNum = 131195;BA.debugLine="ary_str_ink_price(50) = \"30ML 200元\"";
mostCurrent._ary_str_ink_price[(int) (50)] = "30ML 200元";
RDebugUtils.currentLine=131196;
 //BA.debugLineNum = 131196;BA.debugLine="ary_str_ink_price(51) = \"30ML 250元\"";
mostCurrent._ary_str_ink_price[(int) (51)] = "30ML 250元";
RDebugUtils.currentLine=131197;
 //BA.debugLineNum = 131197;BA.debugLine="ary_str_ink_price(52) = \"30ML 230元\"";
mostCurrent._ary_str_ink_price[(int) (52)] = "30ML 230元";
RDebugUtils.currentLine=131198;
 //BA.debugLineNum = 131198;BA.debugLine="ary_str_ink_price(53) = \"28.4ML 280元\"";
mostCurrent._ary_str_ink_price[(int) (53)] = "28.4ML 280元";
RDebugUtils.currentLine=131199;
 //BA.debugLineNum = 131199;BA.debugLine="ary_str_ink_price(54) = \"50ML 190元\"";
mostCurrent._ary_str_ink_price[(int) (54)] = "50ML 190元";
RDebugUtils.currentLine=131201;
 //BA.debugLineNum = 131201;BA.debugLine="ary_dbl_ink_value(0) = 9.6";
_ary_dbl_ink_value[(int) (0)] = 9.6;
RDebugUtils.currentLine=131202;
 //BA.debugLineNum = 131202;BA.debugLine="ary_dbl_ink_value(1) = 11";
_ary_dbl_ink_value[(int) (1)] = 11;
RDebugUtils.currentLine=131203;
 //BA.debugLineNum = 131203;BA.debugLine="ary_dbl_ink_value(2) = 8.8";
_ary_dbl_ink_value[(int) (2)] = 8.8;
RDebugUtils.currentLine=131204;
 //BA.debugLineNum = 131204;BA.debugLine="ary_dbl_ink_value(3) = 3.75";
_ary_dbl_ink_value[(int) (3)] = 3.75;
RDebugUtils.currentLine=131205;
 //BA.debugLineNum = 131205;BA.debugLine="ary_dbl_ink_value(4) = 8.125";
_ary_dbl_ink_value[(int) (4)] = 8.125;
RDebugUtils.currentLine=131206;
 //BA.debugLineNum = 131206;BA.debugLine="ary_dbl_ink_value(5) = 9";
_ary_dbl_ink_value[(int) (5)] = 9;
RDebugUtils.currentLine=131207;
 //BA.debugLineNum = 131207;BA.debugLine="ary_dbl_ink_value(6) = 3.33";
_ary_dbl_ink_value[(int) (6)] = 3.33;
RDebugUtils.currentLine=131208;
 //BA.debugLineNum = 131208;BA.debugLine="ary_dbl_ink_value(7) = 3.66";
_ary_dbl_ink_value[(int) (7)] = 3.66;
RDebugUtils.currentLine=131209;
 //BA.debugLineNum = 131209;BA.debugLine="ary_dbl_ink_value(8) = 14.66";
_ary_dbl_ink_value[(int) (8)] = 14.66;
RDebugUtils.currentLine=131210;
 //BA.debugLineNum = 131210;BA.debugLine="ary_dbl_ink_value(9) = 10";
_ary_dbl_ink_value[(int) (9)] = 10;
RDebugUtils.currentLine=131211;
 //BA.debugLineNum = 131211;BA.debugLine="ary_dbl_ink_value(10) = 5.6";
_ary_dbl_ink_value[(int) (10)] = 5.6;
RDebugUtils.currentLine=131212;
 //BA.debugLineNum = 131212;BA.debugLine="ary_dbl_ink_value(11) = 7";
_ary_dbl_ink_value[(int) (11)] = 7;
RDebugUtils.currentLine=131213;
 //BA.debugLineNum = 131213;BA.debugLine="ary_dbl_ink_value(12) = 7";
_ary_dbl_ink_value[(int) (12)] = 7;
RDebugUtils.currentLine=131214;
 //BA.debugLineNum = 131214;BA.debugLine="ary_dbl_ink_value(13) = 6";
_ary_dbl_ink_value[(int) (13)] = 6;
RDebugUtils.currentLine=131215;
 //BA.debugLineNum = 131215;BA.debugLine="ary_dbl_ink_value(14) = 9";
_ary_dbl_ink_value[(int) (14)] = 9;
RDebugUtils.currentLine=131216;
 //BA.debugLineNum = 131216;BA.debugLine="ary_dbl_ink_value(15) = 9";
_ary_dbl_ink_value[(int) (15)] = 9;
RDebugUtils.currentLine=131217;
 //BA.debugLineNum = 131217;BA.debugLine="ary_dbl_ink_value(16) = 4";
_ary_dbl_ink_value[(int) (16)] = 4;
RDebugUtils.currentLine=131218;
 //BA.debugLineNum = 131218;BA.debugLine="ary_dbl_ink_value(17) = 15.71";
_ary_dbl_ink_value[(int) (17)] = 15.71;
RDebugUtils.currentLine=131219;
 //BA.debugLineNum = 131219;BA.debugLine="ary_dbl_ink_value(18) = 9.16";
_ary_dbl_ink_value[(int) (18)] = 9.16;
RDebugUtils.currentLine=131220;
 //BA.debugLineNum = 131220;BA.debugLine="ary_dbl_ink_value(19) = 10";
_ary_dbl_ink_value[(int) (19)] = 10;
RDebugUtils.currentLine=131221;
 //BA.debugLineNum = 131221;BA.debugLine="ary_dbl_ink_value(20) = 12.8";
_ary_dbl_ink_value[(int) (20)] = 12.8;
RDebugUtils.currentLine=131222;
 //BA.debugLineNum = 131222;BA.debugLine="ary_dbl_ink_value(21) = 12.86";
_ary_dbl_ink_value[(int) (21)] = 12.86;
RDebugUtils.currentLine=131223;
 //BA.debugLineNum = 131223;BA.debugLine="ary_dbl_ink_value(22) = 14.29";
_ary_dbl_ink_value[(int) (22)] = 14.29;
RDebugUtils.currentLine=131224;
 //BA.debugLineNum = 131224;BA.debugLine="ary_dbl_ink_value(23) = 18.57";
_ary_dbl_ink_value[(int) (23)] = 18.57;
RDebugUtils.currentLine=131225;
 //BA.debugLineNum = 131225;BA.debugLine="ary_dbl_ink_value(24) = 3.84";
_ary_dbl_ink_value[(int) (24)] = 3.84;
RDebugUtils.currentLine=131226;
 //BA.debugLineNum = 131226;BA.debugLine="ary_dbl_ink_value(25) = 8";
_ary_dbl_ink_value[(int) (25)] = 8;
RDebugUtils.currentLine=131227;
 //BA.debugLineNum = 131227;BA.debugLine="ary_dbl_ink_value(26) = 9.8";
_ary_dbl_ink_value[(int) (26)] = 9.8;
RDebugUtils.currentLine=131228;
 //BA.debugLineNum = 131228;BA.debugLine="ary_dbl_ink_value(27) = 10.5";
_ary_dbl_ink_value[(int) (27)] = 10.5;
RDebugUtils.currentLine=131229;
 //BA.debugLineNum = 131229;BA.debugLine="ary_dbl_ink_value(28) = 5";
_ary_dbl_ink_value[(int) (28)] = 5;
RDebugUtils.currentLine=131230;
 //BA.debugLineNum = 131230;BA.debugLine="ary_dbl_ink_value(29) = 6";
_ary_dbl_ink_value[(int) (29)] = 6;
RDebugUtils.currentLine=131231;
 //BA.debugLineNum = 131231;BA.debugLine="ary_dbl_ink_value(30) = 6.66";
_ary_dbl_ink_value[(int) (30)] = 6.66;
RDebugUtils.currentLine=131232;
 //BA.debugLineNum = 131232;BA.debugLine="ary_dbl_ink_value(31) = 5";
_ary_dbl_ink_value[(int) (31)] = 5;
RDebugUtils.currentLine=131233;
 //BA.debugLineNum = 131233;BA.debugLine="ary_dbl_ink_value(32) = 6";
_ary_dbl_ink_value[(int) (32)] = 6;
RDebugUtils.currentLine=131234;
 //BA.debugLineNum = 131234;BA.debugLine="ary_dbl_ink_value(33) = 15";
_ary_dbl_ink_value[(int) (33)] = 15;
RDebugUtils.currentLine=131235;
 //BA.debugLineNum = 131235;BA.debugLine="ary_dbl_ink_value(34) = 6";
_ary_dbl_ink_value[(int) (34)] = 6;
RDebugUtils.currentLine=131236;
 //BA.debugLineNum = 131236;BA.debugLine="ary_dbl_ink_value(35) = 12.5";
_ary_dbl_ink_value[(int) (35)] = 12.5;
RDebugUtils.currentLine=131237;
 //BA.debugLineNum = 131237;BA.debugLine="ary_dbl_ink_value(36) = 14";
_ary_dbl_ink_value[(int) (36)] = 14;
RDebugUtils.currentLine=131238;
 //BA.debugLineNum = 131238;BA.debugLine="ary_dbl_ink_value(37) = 10";
_ary_dbl_ink_value[(int) (37)] = 10;
RDebugUtils.currentLine=131239;
 //BA.debugLineNum = 131239;BA.debugLine="ary_dbl_ink_value(38) = 13.75";
_ary_dbl_ink_value[(int) (38)] = 13.75;
RDebugUtils.currentLine=131240;
 //BA.debugLineNum = 131240;BA.debugLine="ary_dbl_ink_value(39) = 13.75";
_ary_dbl_ink_value[(int) (39)] = 13.75;
RDebugUtils.currentLine=131241;
 //BA.debugLineNum = 131241;BA.debugLine="ary_dbl_ink_value(40) = 16.25";
_ary_dbl_ink_value[(int) (40)] = 16.25;
RDebugUtils.currentLine=131242;
 //BA.debugLineNum = 131242;BA.debugLine="ary_dbl_ink_value(41) = 13";
_ary_dbl_ink_value[(int) (41)] = 13;
RDebugUtils.currentLine=131243;
 //BA.debugLineNum = 131243;BA.debugLine="ary_dbl_ink_value(42) = 16";
_ary_dbl_ink_value[(int) (42)] = 16;
RDebugUtils.currentLine=131244;
 //BA.debugLineNum = 131244;BA.debugLine="ary_dbl_ink_value(43) = 10";
_ary_dbl_ink_value[(int) (43)] = 10;
RDebugUtils.currentLine=131245;
 //BA.debugLineNum = 131245;BA.debugLine="ary_dbl_ink_value(44) = 12";
_ary_dbl_ink_value[(int) (44)] = 12;
RDebugUtils.currentLine=131246;
 //BA.debugLineNum = 131246;BA.debugLine="ary_dbl_ink_value(45) = 18.9";
_ary_dbl_ink_value[(int) (45)] = 18.9;
RDebugUtils.currentLine=131247;
 //BA.debugLineNum = 131247;BA.debugLine="ary_dbl_ink_value(46) = 4";
_ary_dbl_ink_value[(int) (46)] = 4;
RDebugUtils.currentLine=131248;
 //BA.debugLineNum = 131248;BA.debugLine="ary_dbl_ink_value(47) = 1.2";
_ary_dbl_ink_value[(int) (47)] = 1.2;
RDebugUtils.currentLine=131249;
 //BA.debugLineNum = 131249;BA.debugLine="ary_dbl_ink_value(48) = 8";
_ary_dbl_ink_value[(int) (48)] = 8;
RDebugUtils.currentLine=131250;
 //BA.debugLineNum = 131250;BA.debugLine="ary_dbl_ink_value(49) = 11";
_ary_dbl_ink_value[(int) (49)] = 11;
RDebugUtils.currentLine=131251;
 //BA.debugLineNum = 131251;BA.debugLine="ary_dbl_ink_value(50) = 6.66";
_ary_dbl_ink_value[(int) (50)] = 6.66;
RDebugUtils.currentLine=131252;
 //BA.debugLineNum = 131252;BA.debugLine="ary_dbl_ink_value(51) = 8.33";
_ary_dbl_ink_value[(int) (51)] = 8.33;
RDebugUtils.currentLine=131253;
 //BA.debugLineNum = 131253;BA.debugLine="ary_dbl_ink_value(52) = 7.66";
_ary_dbl_ink_value[(int) (52)] = 7.66;
RDebugUtils.currentLine=131254;
 //BA.debugLineNum = 131254;BA.debugLine="ary_dbl_ink_value(53) = 9.86";
_ary_dbl_ink_value[(int) (53)] = 9.86;
RDebugUtils.currentLine=131255;
 //BA.debugLineNum = 131255;BA.debugLine="ary_dbl_ink_value(54) = 3.8";
_ary_dbl_ink_value[(int) (54)] = 3.8;
RDebugUtils.currentLine=131257;
 //BA.debugLineNum = 131257;BA.debugLine="ary_str_profit_name(0) = \"10%\"";
mostCurrent._ary_str_profit_name[(int) (0)] = "10%";
RDebugUtils.currentLine=131258;
 //BA.debugLineNum = 131258;BA.debugLine="ary_str_profit_name(1) = \"20%\"";
mostCurrent._ary_str_profit_name[(int) (1)] = "20%";
RDebugUtils.currentLine=131259;
 //BA.debugLineNum = 131259;BA.debugLine="ary_str_profit_name(2) = \"25%\"";
mostCurrent._ary_str_profit_name[(int) (2)] = "25%";
RDebugUtils.currentLine=131260;
 //BA.debugLineNum = 131260;BA.debugLine="ary_str_profit_name(3) = \"30%\"";
mostCurrent._ary_str_profit_name[(int) (3)] = "30%";
RDebugUtils.currentLine=131262;
 //BA.debugLineNum = 131262;BA.debugLine="ary_str_profit_unit(0) = \"玻璃瓶10元\"";
mostCurrent._ary_str_profit_unit[(int) (0)] = "玻璃瓶10元";
RDebugUtils.currentLine=131263;
 //BA.debugLineNum = 131263;BA.debugLine="ary_str_profit_unit(1) = \"玻璃瓶10元\"";
mostCurrent._ary_str_profit_unit[(int) (1)] = "玻璃瓶10元";
RDebugUtils.currentLine=131264;
 //BA.debugLineNum = 131264;BA.debugLine="ary_str_profit_unit(2) = \"玻璃瓶10元\"";
mostCurrent._ary_str_profit_unit[(int) (2)] = "玻璃瓶10元";
RDebugUtils.currentLine=131265;
 //BA.debugLineNum = 131265;BA.debugLine="ary_str_profit_unit(3) = \"玻璃瓶10元\"";
mostCurrent._ary_str_profit_unit[(int) (3)] = "玻璃瓶10元";
RDebugUtils.currentLine=131267;
 //BA.debugLineNum = 131267;BA.debugLine="ary_dbl_profit_value(0) = 1.1";
_ary_dbl_profit_value[(int) (0)] = 1.1;
RDebugUtils.currentLine=131268;
 //BA.debugLineNum = 131268;BA.debugLine="ary_dbl_profit_value(1) = 1.2";
_ary_dbl_profit_value[(int) (1)] = 1.2;
RDebugUtils.currentLine=131269;
 //BA.debugLineNum = 131269;BA.debugLine="ary_dbl_profit_value(2) = 1.25";
_ary_dbl_profit_value[(int) (2)] = 1.25;
RDebugUtils.currentLine=131270;
 //BA.debugLineNum = 131270;BA.debugLine="ary_dbl_profit_value(3) = 1.3";
_ary_dbl_profit_value[(int) (3)] = 1.3;
RDebugUtils.currentLine=131272;
 //BA.debugLineNum = 131272;BA.debugLine="Button_clear_Click";
_button_clear_click();
RDebugUtils.currentLine=131273;
 //BA.debugLineNum = 131273;BA.debugLine="sub_ink_ml_menu_initial";
_sub_ink_ml_menu_initial();
RDebugUtils.currentLine=131274;
 //BA.debugLineNum = 131274;BA.debugLine="sub_ink_menu_initial";
_sub_ink_menu_initial();
RDebugUtils.currentLine=131275;
 //BA.debugLineNum = 131275;BA.debugLine="sub_profit_menu_initial";
_sub_profit_menu_initial();
RDebugUtils.currentLine=131276;
 //BA.debugLineNum = 131276;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=131277;
 //BA.debugLineNum = 131277;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=131278;
 //BA.debugLineNum = 131278;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=131279;
 //BA.debugLineNum = 131279;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=131281;
 //BA.debugLineNum = 131281;BA.debugLine="End Sub";
return "";
}
public static String  _button_clear_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "button_clear_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "button_clear_click", null);
RDebugUtils.currentLine=786432;
 //BA.debugLineNum = 786432;BA.debugLine="Sub Button_clear_Click";
RDebugUtils.currentLine=786434;
 //BA.debugLineNum = 786434;BA.debugLine="int_select_ink_ml_index=cnt_default_ink_ml_index";
_int_select_ink_ml_index = _cnt_default_ink_ml_index;
RDebugUtils.currentLine=786435;
 //BA.debugLineNum = 786435;BA.debugLine="int_select_ink_index=cnt_default_ink_name_index";
_int_select_ink_index = _cnt_default_ink_name_index;
RDebugUtils.currentLine=786436;
 //BA.debugLineNum = 786436;BA.debugLine="int_select_profit_index=cnt_default_profit_name_i";
_int_select_profit_index = _cnt_default_profit_name_index;
RDebugUtils.currentLine=786437;
 //BA.debugLineNum = 786437;BA.debugLine="int_cal_result=0";
_int_cal_result = (int) (0);
RDebugUtils.currentLine=786438;
 //BA.debugLineNum = 786438;BA.debugLine="int_bottle=0";
_int_bottle = (int) (0);
RDebugUtils.currentLine=786439;
 //BA.debugLineNum = 786439;BA.debugLine="sub_update_menu";
_sub_update_menu();
RDebugUtils.currentLine=786440;
 //BA.debugLineNum = 786440;BA.debugLine="End Sub";
return "";
}
public static String  _sub_ink_ml_menu_initial() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "sub_ink_ml_menu_initial"))
	return (String) Debug.delegate(mostCurrent.activityBA, "sub_ink_ml_menu_initial", null);
int _i = 0;
RDebugUtils.currentLine=393216;
 //BA.debugLineNum = 393216;BA.debugLine="Sub sub_ink_ml_menu_initial";
RDebugUtils.currentLine=393217;
 //BA.debugLineNum = 393217;BA.debugLine="For i = 0 To (cnt_int_ink_ml_array_size-1)";
{
final int step1 = 1;
final int limit1 = (int) ((_cnt_int_ink_ml_array_size-1));
_i = (int) (0) ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
RDebugUtils.currentLine=393218;
 //BA.debugLineNum = 393218;BA.debugLine="ListView_ink_ml.AddsingleLine2(ary_str_ink_ml_na";
mostCurrent._listview_ink_ml.AddSingleLine2(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_ml_name[_i]),(Object)(_ary_int_ink_ml_value[_i]));
 }
};
RDebugUtils.currentLine=393220;
 //BA.debugLineNum = 393220;BA.debugLine="End Sub";
return "";
}
public static String  _sub_ink_menu_initial() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "sub_ink_menu_initial"))
	return (String) Debug.delegate(mostCurrent.activityBA, "sub_ink_menu_initial", null);
int _i = 0;
RDebugUtils.currentLine=458752;
 //BA.debugLineNum = 458752;BA.debugLine="Sub sub_ink_menu_initial";
RDebugUtils.currentLine=458753;
 //BA.debugLineNum = 458753;BA.debugLine="For i = 0 To (cnt_int_ink_array_size-1)";
{
final int step1 = 1;
final int limit1 = (int) ((_cnt_int_ink_array_size-1));
_i = (int) (0) ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
RDebugUtils.currentLine=458754;
 //BA.debugLineNum = 458754;BA.debugLine="ListView_ink.AddTwoLines2(ary_str_ink_name(i),ar";
mostCurrent._listview_ink.AddTwoLines2(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_name[_i]),BA.ObjectToCharSequence(mostCurrent._ary_str_ink_price[_i]),(Object)(_ary_dbl_ink_value[_i]));
 }
};
RDebugUtils.currentLine=458756;
 //BA.debugLineNum = 458756;BA.debugLine="End Sub";
return "";
}
public static String  _sub_profit_menu_initial() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "sub_profit_menu_initial"))
	return (String) Debug.delegate(mostCurrent.activityBA, "sub_profit_menu_initial", null);
int _i = 0;
RDebugUtils.currentLine=524288;
 //BA.debugLineNum = 524288;BA.debugLine="Sub sub_profit_menu_initial";
RDebugUtils.currentLine=524289;
 //BA.debugLineNum = 524289;BA.debugLine="For i = 0 To (cnt_int_profit_array_size-1)";
{
final int step1 = 1;
final int limit1 = (int) ((_cnt_int_profit_array_size-1));
_i = (int) (0) ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
RDebugUtils.currentLine=524290;
 //BA.debugLineNum = 524290;BA.debugLine="ListView_profit.AddTwoLines2(ary_str_profit_name";
mostCurrent._listview_profit.AddTwoLines2(BA.ObjectToCharSequence(mostCurrent._ary_str_profit_name[_i]),BA.ObjectToCharSequence(mostCurrent._ary_str_profit_unit[_i]),(Object)(_ary_dbl_profit_value[_i]));
 }
};
RDebugUtils.currentLine=524292;
 //BA.debugLineNum = 524292;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=262144;
 //BA.debugLineNum = 262144;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
RDebugUtils.currentLine=262146;
 //BA.debugLineNum = 262146;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "activity_resume"))
	return (String) Debug.delegate(mostCurrent.activityBA, "activity_resume", null);
RDebugUtils.currentLine=196608;
 //BA.debugLineNum = 196608;BA.debugLine="Sub Activity_Resume";
RDebugUtils.currentLine=196610;
 //BA.debugLineNum = 196610;BA.debugLine="End Sub";
return "";
}
public static String  _button_bottle_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "button_bottle_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "button_bottle_click", null);
RDebugUtils.currentLine=983040;
 //BA.debugLineNum = 983040;BA.debugLine="Sub Button_bottle_Click";
RDebugUtils.currentLine=983042;
 //BA.debugLineNum = 983042;BA.debugLine="If int_cal_result>0 And int_bottle>=1 Then";
if (_int_cal_result>0 && _int_bottle>=1) { 
RDebugUtils.currentLine=983043;
 //BA.debugLineNum = 983043;BA.debugLine="int_cal_result=Round(int_cal_result-(int_bottle*";
_int_cal_result = (int) (anywheresoftware.b4a.keywords.Common.Round(_int_cal_result-(_int_bottle*10)));
 }else {
RDebugUtils.currentLine=983045;
 //BA.debugLineNum = 983045;BA.debugLine="Msgbox(\"無法折讓空瓶\",\"警告\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("無法折讓空瓶"),BA.ObjectToCharSequence("警告"),mostCurrent.activityBA);
 };
RDebugUtils.currentLine=983047;
 //BA.debugLineNum = 983047;BA.debugLine="sub_update_menu";
_sub_update_menu();
RDebugUtils.currentLine=983048;
 //BA.debugLineNum = 983048;BA.debugLine="End Sub";
return "";
}
public static String  _sub_update_menu() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "sub_update_menu"))
	return (String) Debug.delegate(mostCurrent.activityBA, "sub_update_menu", null);
RDebugUtils.currentLine=327680;
 //BA.debugLineNum = 327680;BA.debugLine="Sub sub_update_menu";
RDebugUtils.currentLine=327681;
 //BA.debugLineNum = 327681;BA.debugLine="Label_ink_ml.Text = ary_str_ink_ml_name(int_selec";
mostCurrent._label_ink_ml.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_ml_name[_int_select_ink_ml_index]));
RDebugUtils.currentLine=327682;
 //BA.debugLineNum = 327682;BA.debugLine="Label_ink_name.Text = ary_str_ink_name(int_select";
mostCurrent._label_ink_name.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_name[_int_select_ink_index]));
RDebugUtils.currentLine=327683;
 //BA.debugLineNum = 327683;BA.debugLine="Label_ink_price.Text = ary_str_ink_price(int_sele";
mostCurrent._label_ink_price.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_price[_int_select_ink_index]));
RDebugUtils.currentLine=327684;
 //BA.debugLineNum = 327684;BA.debugLine="Label_profit_name.Text = ary_str_profit_name(int_";
mostCurrent._label_profit_name.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_profit_name[_int_select_profit_index]));
RDebugUtils.currentLine=327685;
 //BA.debugLineNum = 327685;BA.debugLine="Label_profit_unit.Text = ary_str_profit_unit(int_";
mostCurrent._label_profit_unit.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_profit_unit[_int_select_profit_index]));
RDebugUtils.currentLine=327686;
 //BA.debugLineNum = 327686;BA.debugLine="EditTextResult.Text = int_cal_result";
mostCurrent._edittextresult.setText(BA.ObjectToCharSequence(_int_cal_result));
RDebugUtils.currentLine=327687;
 //BA.debugLineNum = 327687;BA.debugLine="End Sub";
return "";
}
public static String  _button_ink_ml_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "button_ink_ml_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "button_ink_ml_click", null);
RDebugUtils.currentLine=589824;
 //BA.debugLineNum = 589824;BA.debugLine="Sub Button_ink_ml_Click";
RDebugUtils.currentLine=589825;
 //BA.debugLineNum = 589825;BA.debugLine="Panel_ink_ml.Visible = True";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=589826;
 //BA.debugLineNum = 589826;BA.debugLine="End Sub";
return "";
}
public static String  _button_ink_price_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "button_ink_price_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "button_ink_price_click", null);
RDebugUtils.currentLine=655360;
 //BA.debugLineNum = 655360;BA.debugLine="Sub Button_ink_price_Click";
RDebugUtils.currentLine=655361;
 //BA.debugLineNum = 655361;BA.debugLine="Panel_ink.Visible = True";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=655362;
 //BA.debugLineNum = 655362;BA.debugLine="End Sub";
return "";
}
public static String  _button_one_bottle_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "button_one_bottle_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "button_one_bottle_click", null);
RDebugUtils.currentLine=1048576;
 //BA.debugLineNum = 1048576;BA.debugLine="Sub Button_one_bottle_Click";
RDebugUtils.currentLine=1048578;
 //BA.debugLineNum = 1048578;BA.debugLine="If int_cal_result>0 Then";
if (_int_cal_result>0) { 
RDebugUtils.currentLine=1048579;
 //BA.debugLineNum = 1048579;BA.debugLine="int_cal_result=int_cal_result-10";
_int_cal_result = (int) (_int_cal_result-10);
 }else {
RDebugUtils.currentLine=1048581;
 //BA.debugLineNum = 1048581;BA.debugLine="Msgbox(\"沒有餘額，無法折讓空瓶\",\"警告\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("沒有餘額，無法折讓空瓶"),BA.ObjectToCharSequence("警告"),mostCurrent.activityBA);
 };
RDebugUtils.currentLine=1048583;
 //BA.debugLineNum = 1048583;BA.debugLine="sub_update_menu";
_sub_update_menu();
RDebugUtils.currentLine=1048584;
 //BA.debugLineNum = 1048584;BA.debugLine="End Sub";
return "";
}
public static String  _button_profit_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "button_profit_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "button_profit_click", null);
RDebugUtils.currentLine=720896;
 //BA.debugLineNum = 720896;BA.debugLine="Sub Button_profit_Click";
RDebugUtils.currentLine=720897;
 //BA.debugLineNum = 720897;BA.debugLine="Panel_profit.Visible = True";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=720898;
 //BA.debugLineNum = 720898;BA.debugLine="End Sub";
return "";
}
public static String  _button_single_calculation_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "button_single_calculation_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "button_single_calculation_click", null);
RDebugUtils.currentLine=851968;
 //BA.debugLineNum = 851968;BA.debugLine="Sub Button_single_calculation_Click";
RDebugUtils.currentLine=851970;
 //BA.debugLineNum = 851970;BA.debugLine="int_bottle=1";
_int_bottle = (int) (1);
RDebugUtils.currentLine=851971;
 //BA.debugLineNum = 851971;BA.debugLine="int_cal_result=Round((ary_int_ink_ml_value(int_se";
_int_cal_result = (int) (anywheresoftware.b4a.keywords.Common.Round((_ary_int_ink_ml_value[_int_select_ink_ml_index]*_ary_dbl_ink_value[_int_select_ink_index]*_ary_dbl_profit_value[_int_select_profit_index]+10)));
RDebugUtils.currentLine=851972;
 //BA.debugLineNum = 851972;BA.debugLine="sub_update_menu";
_sub_update_menu();
RDebugUtils.currentLine=851973;
 //BA.debugLineNum = 851973;BA.debugLine="End Sub";
return "";
}
public static String  _button_total_calculation_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "button_total_calculation_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "button_total_calculation_click", null);
RDebugUtils.currentLine=917504;
 //BA.debugLineNum = 917504;BA.debugLine="Sub Button_total_calculation_Click";
RDebugUtils.currentLine=917506;
 //BA.debugLineNum = 917506;BA.debugLine="int_cal_result=int_cal_result+Round((ary_int_ink_";
_int_cal_result = (int) (_int_cal_result+anywheresoftware.b4a.keywords.Common.Round((_ary_int_ink_ml_value[_int_select_ink_ml_index]*_ary_dbl_ink_value[_int_select_ink_index]*_ary_dbl_profit_value[_int_select_profit_index]+10)));
RDebugUtils.currentLine=917507;
 //BA.debugLineNum = 917507;BA.debugLine="int_bottle=int_bottle+1";
_int_bottle = (int) (_int_bottle+1);
RDebugUtils.currentLine=917508;
 //BA.debugLineNum = 917508;BA.debugLine="sub_update_menu";
_sub_update_menu();
RDebugUtils.currentLine=917509;
 //BA.debugLineNum = 917509;BA.debugLine="End Sub";
return "";
}
public static String  _listview_ink_itemclick(int _position,Object _value) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "listview_ink_itemclick"))
	return (String) Debug.delegate(mostCurrent.activityBA, "listview_ink_itemclick", new Object[] {_position,_value});
RDebugUtils.currentLine=1179648;
 //BA.debugLineNum = 1179648;BA.debugLine="Sub ListView_ink_ItemClick (Position As Int, Value";
RDebugUtils.currentLine=1179649;
 //BA.debugLineNum = 1179649;BA.debugLine="int_select_ink_index=Position";
_int_select_ink_index = _position;
RDebugUtils.currentLine=1179650;
 //BA.debugLineNum = 1179650;BA.debugLine="sub_update_menu";
_sub_update_menu();
RDebugUtils.currentLine=1179652;
 //BA.debugLineNum = 1179652;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=1179653;
 //BA.debugLineNum = 1179653;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1179654;
 //BA.debugLineNum = 1179654;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1179655;
 //BA.debugLineNum = 1179655;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1179656;
 //BA.debugLineNum = 1179656;BA.debugLine="End Sub";
return "";
}
public static String  _listview_ink_ml_itemclick(int _position,Object _value) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "listview_ink_ml_itemclick"))
	return (String) Debug.delegate(mostCurrent.activityBA, "listview_ink_ml_itemclick", new Object[] {_position,_value});
RDebugUtils.currentLine=1114112;
 //BA.debugLineNum = 1114112;BA.debugLine="Sub ListView_ink_ml_ItemClick (Position As Int, Va";
RDebugUtils.currentLine=1114113;
 //BA.debugLineNum = 1114113;BA.debugLine="int_select_ink_ml_index=Position";
_int_select_ink_ml_index = _position;
RDebugUtils.currentLine=1114114;
 //BA.debugLineNum = 1114114;BA.debugLine="sub_update_menu";
_sub_update_menu();
RDebugUtils.currentLine=1114116;
 //BA.debugLineNum = 1114116;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=1114117;
 //BA.debugLineNum = 1114117;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114118;
 //BA.debugLineNum = 1114118;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114119;
 //BA.debugLineNum = 1114119;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114120;
 //BA.debugLineNum = 1114120;BA.debugLine="End Sub";
return "";
}
public static String  _listview_profit_itemclick(int _position,Object _value) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "listview_profit_itemclick"))
	return (String) Debug.delegate(mostCurrent.activityBA, "listview_profit_itemclick", new Object[] {_position,_value});
RDebugUtils.currentLine=1245184;
 //BA.debugLineNum = 1245184;BA.debugLine="Sub ListView_profit_ItemClick (Position As Int, Va";
RDebugUtils.currentLine=1245185;
 //BA.debugLineNum = 1245185;BA.debugLine="int_select_profit_index=Position";
_int_select_profit_index = _position;
RDebugUtils.currentLine=1245186;
 //BA.debugLineNum = 1245186;BA.debugLine="sub_update_menu";
_sub_update_menu();
RDebugUtils.currentLine=1245188;
 //BA.debugLineNum = 1245188;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=1245189;
 //BA.debugLineNum = 1245189;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1245190;
 //BA.debugLineNum = 1245190;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1245191;
 //BA.debugLineNum = 1245191;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1245192;
 //BA.debugLineNum = 1245192;BA.debugLine="End Sub";
return "";
}
}