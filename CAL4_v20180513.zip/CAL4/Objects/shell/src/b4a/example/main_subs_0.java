package b4a.example;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,69);
if (RapidSub.canDelegate("activity_create")) return b4a.example.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 69;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(16);
 BA.debugLineNum = 71;BA.debugLine="Activity.LoadLayout(\"1\")";
Debug.ShouldStop(64);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 72;BA.debugLine="Activity.Title = \"分裝價格計算機(墨水) V2018-05-13\"";
Debug.ShouldStop(128);
main.mostCurrent._activity.runMethod(false,"setTitle",BA.ObjectToCharSequence("分裝價格計算機(墨水) V2018-05-13"));
 BA.debugLineNum = 74;BA.debugLine="ary_str_ink_ml_name(0) = \"5ml\"";
Debug.ShouldStop(512);
main.mostCurrent._ary_str_ink_ml_name.setArrayElement (BA.ObjectToString("5ml"),BA.numberCast(int.class, 0));
 BA.debugLineNum = 75;BA.debugLine="ary_str_ink_ml_name(1) = \"10ml\"";
Debug.ShouldStop(1024);
main.mostCurrent._ary_str_ink_ml_name.setArrayElement (BA.ObjectToString("10ml"),BA.numberCast(int.class, 1));
 BA.debugLineNum = 76;BA.debugLine="ary_str_ink_ml_name(2) = \"3ml\"";
Debug.ShouldStop(2048);
main.mostCurrent._ary_str_ink_ml_name.setArrayElement (BA.ObjectToString("3ml"),BA.numberCast(int.class, 2));
 BA.debugLineNum = 77;BA.debugLine="ary_str_ink_ml_name(3) = \"6ml\"";
Debug.ShouldStop(4096);
main.mostCurrent._ary_str_ink_ml_name.setArrayElement (BA.ObjectToString("6ml"),BA.numberCast(int.class, 3));
 BA.debugLineNum = 78;BA.debugLine="ary_str_ink_ml_name(4) = \"8ml\"";
Debug.ShouldStop(8192);
main.mostCurrent._ary_str_ink_ml_name.setArrayElement (BA.ObjectToString("8ml"),BA.numberCast(int.class, 4));
 BA.debugLineNum = 80;BA.debugLine="ary_int_ink_ml_value(0) = 5";
Debug.ShouldStop(32768);
main._ary_int_ink_ml_value.setArrayElement (BA.numberCast(int.class, 5),BA.numberCast(int.class, 0));
 BA.debugLineNum = 81;BA.debugLine="ary_int_ink_ml_value(1) = 10";
Debug.ShouldStop(65536);
main._ary_int_ink_ml_value.setArrayElement (BA.numberCast(int.class, 10),BA.numberCast(int.class, 1));
 BA.debugLineNum = 82;BA.debugLine="ary_int_ink_ml_value(2) = 3";
Debug.ShouldStop(131072);
main._ary_int_ink_ml_value.setArrayElement (BA.numberCast(int.class, 3),BA.numberCast(int.class, 2));
 BA.debugLineNum = 83;BA.debugLine="ary_int_ink_ml_value(3) = 6";
Debug.ShouldStop(262144);
main._ary_int_ink_ml_value.setArrayElement (BA.numberCast(int.class, 6),BA.numberCast(int.class, 3));
 BA.debugLineNum = 84;BA.debugLine="ary_int_ink_ml_value(4) = 8";
Debug.ShouldStop(524288);
main._ary_int_ink_ml_value.setArrayElement (BA.numberCast(int.class, 8),BA.numberCast(int.class, 4));
 BA.debugLineNum = 86;BA.debugLine="ary_str_ink_name(0) = \"Pilot 百樂 Iroshizuku 色彩墨水\"";
Debug.ShouldStop(2097152);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("Pilot 百樂 Iroshizuku 色彩墨水"),BA.numberCast(int.class, 0));
 BA.debugLineNum = 87;BA.debugLine="ary_str_ink_name(1) = \"日本 KOBE INK物語 限定墨水\"";
Debug.ShouldStop(4194304);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本 KOBE INK物語 限定墨水"),BA.numberCast(int.class, 1));
 BA.debugLineNum = 88;BA.debugLine="ary_str_ink_name(2) = \"DIAMINE SHIMMERTASTIC 金銀粉\"";
Debug.ShouldStop(8388608);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("DIAMINE SHIMMERTASTIC 金銀粉"),BA.numberCast(int.class, 2));
 BA.debugLineNum = 89;BA.debugLine="ary_str_ink_name(3) = \"英國 DIAMINE 墨水\"";
Debug.ShouldStop(16777216);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("英國 DIAMINE 墨水"),BA.numberCast(int.class, 3));
 BA.debugLineNum = 90;BA.debugLine="ary_str_ink_name(4) = \"英國 DIAMINE 150th 墨水\"";
Debug.ShouldStop(33554432);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("英國 DIAMINE 150th 墨水"),BA.numberCast(int.class, 4));
 BA.debugLineNum = 91;BA.debugLine="ary_str_ink_name(5) = \"英國 DIAMINE 花系列、音樂家墨水\"";
Debug.ShouldStop(67108864);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("英國 DIAMINE 花系列、音樂家墨水"),BA.numberCast(int.class, 5));
 BA.debugLineNum = 92;BA.debugLine="ary_str_ink_name(6) = \"中國 壇水墨水\"";
Debug.ShouldStop(134217728);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("中國 壇水墨水"),BA.numberCast(int.class, 6));
 BA.debugLineNum = 93;BA.debugLine="ary_str_ink_name(7) = \"中國 壇水金銀粉墨水\"";
Debug.ShouldStop(268435456);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("中國 壇水金銀粉墨水"),BA.numberCast(int.class, 7));
 BA.debugLineNum = 94;BA.debugLine="ary_str_ink_name(8) = \"臺灣 醃漬物 墨水\"";
Debug.ShouldStop(536870912);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("臺灣 醃漬物 墨水"),BA.numberCast(int.class, 8));
 BA.debugLineNum = 95;BA.debugLine="ary_str_ink_name(9) = \"臺灣 臺灣人物 墨水\"";
Debug.ShouldStop(1073741824);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("臺灣 臺灣人物 墨水"),BA.numberCast(int.class, 9));
 BA.debugLineNum = 96;BA.debugLine="ary_str_ink_name(10) = \"CROSS 鋼筆墨水\"";
Debug.ShouldStop(-2147483648);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("CROSS 鋼筆墨水"),BA.numberCast(int.class, 10));
 BA.debugLineNum = 97;BA.debugLine="ary_str_ink_name(11) = \"ROHRER & KLINGNER 鋼筆墨水\"";
Debug.ShouldStop(1);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("ROHRER & KLINGNER 鋼筆墨水"),BA.numberCast(int.class, 11));
 BA.debugLineNum = 98;BA.debugLine="ary_str_ink_name(12) = \"ROHRER & KLINGNER 蟲膠金銀墨水\"";
Debug.ShouldStop(2);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("ROHRER & KLINGNER 蟲膠金銀墨水"),BA.numberCast(int.class, 12));
 BA.debugLineNum = 99;BA.debugLine="ary_str_ink_name(13) = \"ROHRER & KLINGNER 蟲膠墨水\"";
Debug.ShouldStop(4);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("ROHRER & KLINGNER 蟲膠墨水"),BA.numberCast(int.class, 13));
 BA.debugLineNum = 100;BA.debugLine="ary_str_ink_name(14) = \"ROHRER & KLINGNER 速寫墨水\"";
Debug.ShouldStop(8);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("ROHRER & KLINGNER 速寫墨水"),BA.numberCast(int.class, 14));
 BA.debugLineNum = 101;BA.debugLine="ary_str_ink_name(15) = \"ROHRER & KLINGNER 防水檔案墨水\"";
Debug.ShouldStop(16);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("ROHRER & KLINGNER 防水檔案墨水"),BA.numberCast(int.class, 15));
 BA.debugLineNum = 102;BA.debugLine="ary_str_ink_name(16) = \"ROHRER & KLINGNER 古典沾水筆墨水";
Debug.ShouldStop(32);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("ROHRER & KLINGNER 古典沾水筆墨水"),BA.numberCast(int.class, 16));
 BA.debugLineNum = 103;BA.debugLine="ary_str_ink_name(17) = \"丹麥 喬治傑森 鋼筆墨水\"";
Debug.ShouldStop(64);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("丹麥 喬治傑森 鋼筆墨水"),BA.numberCast(int.class, 17));
 BA.debugLineNum = 104;BA.debugLine="ary_str_ink_name(18) = \"KWZ 標準鋼筆墨水\"";
Debug.ShouldStop(128);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("KWZ 標準鋼筆墨水"),BA.numberCast(int.class, 18));
 BA.debugLineNum = 105;BA.debugLine="ary_str_ink_name(19) = \"KWZ 防水鐵膽墨水\"";
Debug.ShouldStop(256);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("KWZ 防水鐵膽墨水"),BA.numberCast(int.class, 19));
 BA.debugLineNum = 106;BA.debugLine="ary_str_ink_name(20) = \"Faber-Castell 鋼筆墨水\"";
Debug.ShouldStop(512);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("Faber-Castell 鋼筆墨水"),BA.numberCast(int.class, 20));
 BA.debugLineNum = 107;BA.debugLine="ary_str_ink_name(21) = \"德國 Jansen 手工墨水\"";
Debug.ShouldStop(1024);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("德國 Jansen 手工墨水"),BA.numberCast(int.class, 21));
 BA.debugLineNum = 108;BA.debugLine="ary_str_ink_name(22) = \"德國 Jansen 手工香味墨水\"";
Debug.ShouldStop(2048);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("德國 Jansen 手工香味墨水"),BA.numberCast(int.class, 22));
 BA.debugLineNum = 109;BA.debugLine="ary_str_ink_name(23) = \"德國 Jansen 香奈兒香味墨水\"";
Debug.ShouldStop(4096);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("德國 Jansen 香奈兒香味墨水"),BA.numberCast(int.class, 23));
 BA.debugLineNum = 110;BA.debugLine="ary_str_ink_name(24) = \"百利金 4001 墨水\"";
Debug.ShouldStop(8192);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("百利金 4001 墨水"),BA.numberCast(int.class, 24));
 BA.debugLineNum = 111;BA.debugLine="ary_str_ink_name(25) = \"百利金 4001 碳素墨水\"";
Debug.ShouldStop(16384);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("百利金 4001 碳素墨水"),BA.numberCast(int.class, 25));
 BA.debugLineNum = 112;BA.debugLine="ary_str_ink_name(26) = \"百利金 Edelstein 逸彩墨水\"";
Debug.ShouldStop(32768);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("百利金 Edelstein 逸彩墨水"),BA.numberCast(int.class, 26));
 BA.debugLineNum = 113;BA.debugLine="ary_str_ink_name(27) = \"日本白金 Classic Ink 古典墨水\"";
Debug.ShouldStop(65536);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本白金 Classic Ink 古典墨水"),BA.numberCast(int.class, 27));
 BA.debugLineNum = 114;BA.debugLine="ary_str_ink_name(28) = \"日本白金 Mixable ink 混色墨水\"";
Debug.ShouldStop(131072);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本白金 Mixable ink 混色墨水"),BA.numberCast(int.class, 28));
 BA.debugLineNum = 115;BA.debugLine="ary_str_ink_name(29) = \"日本白金 Mixable ink 墨水調和液\"";
Debug.ShouldStop(262144);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本白金 Mixable ink 墨水調和液"),BA.numberCast(int.class, 29));
 BA.debugLineNum = 116;BA.debugLine="ary_str_ink_name(30) = \"日本白金 超微粒子防水墨水\"";
Debug.ShouldStop(524288);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本白金 超微粒子防水墨水"),BA.numberCast(int.class, 30));
 BA.debugLineNum = 117;BA.debugLine="ary_str_ink_name(31) = \"日本白金 鋼筆墨水\"";
Debug.ShouldStop(1048576);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本白金 鋼筆墨水"),BA.numberCast(int.class, 31));
 BA.debugLineNum = 118;BA.debugLine="ary_str_ink_name(32) = \"寫樂 jentle ink 鋼筆墨水\"";
Debug.ShouldStop(2097152);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("寫樂 jentle ink 鋼筆墨水"),BA.numberCast(int.class, 32));
 BA.debugLineNum = 119;BA.debugLine="ary_str_ink_name(33) = \"寫樂 STORiA 防水墨水\"";
Debug.ShouldStop(4194304);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("寫樂 STORiA 防水墨水"),BA.numberCast(int.class, 33));
 BA.debugLineNum = 120;BA.debugLine="ary_str_ink_name(34) = \"寫樂 （大）四季彩墨水\"";
Debug.ShouldStop(8388608);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("寫樂 （大）四季彩墨水"),BA.numberCast(int.class, 34));
 BA.debugLineNum = 121;BA.debugLine="ary_str_ink_name(35) = \"寫樂 （新）四季彩墨水\"";
Debug.ShouldStop(16777216);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("寫樂 （新）四季彩墨水"),BA.numberCast(int.class, 35));
 BA.debugLineNum = 122;BA.debugLine="ary_str_ink_name(36) = \"寫樂 （新）四季織墨水\"";
Debug.ShouldStop(33554432);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("寫樂 （新）四季織墨水"),BA.numberCast(int.class, 36));
 BA.debugLineNum = 123;BA.debugLine="ary_str_ink_name(37) = \"寫樂 防水墨水\"";
Debug.ShouldStop(67108864);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("寫樂 防水墨水"),BA.numberCast(int.class, 37));
 BA.debugLineNum = 124;BA.debugLine="ary_str_ink_name(38) = \"日本 京之音墨水\"";
Debug.ShouldStop(134217728);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本 京之音墨水"),BA.numberCast(int.class, 38));
 BA.debugLineNum = 125;BA.debugLine="ary_str_ink_name(39) = \"日本 京彩墨水\"";
Debug.ShouldStop(268435456);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本 京彩墨水"),BA.numberCast(int.class, 39));
 BA.debugLineNum = 126;BA.debugLine="ary_str_ink_name(40) = \"日本 京音京彩墨水限定色\"";
Debug.ShouldStop(536870912);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("日本 京音京彩墨水限定色"),BA.numberCast(int.class, 40));
 BA.debugLineNum = 127;BA.debugLine="ary_str_ink_name(41) = \"法國 J. Herbin 1670 墨水\"";
Debug.ShouldStop(1073741824);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("法國 J. Herbin 1670 墨水"),BA.numberCast(int.class, 41));
 BA.debugLineNum = 128;BA.debugLine="ary_str_ink_name(42) = \"法國 J. Herbin 1798 墨水\"";
Debug.ShouldStop(-2147483648);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("法國 J. Herbin 1798 墨水"),BA.numberCast(int.class, 42));
 BA.debugLineNum = 129;BA.debugLine="ary_str_ink_name(43) = \"法國 J. Herbin 珍珠彩墨 墨水\"";
Debug.ShouldStop(1);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("法國 J. Herbin 珍珠彩墨 墨水"),BA.numberCast(int.class, 43));
 BA.debugLineNum = 130;BA.debugLine="ary_str_ink_name(44) = \"法國 都彭 S.T. DUPONT 鋼筆墨水\"";
Debug.ShouldStop(2);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("法國 都彭 S.T. DUPONT 鋼筆墨水"),BA.numberCast(int.class, 44));
 BA.debugLineNum = 131;BA.debugLine="ary_str_ink_name(45) = \"瑞士 卡達 鋼筆墨水\"";
Debug.ShouldStop(4);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("瑞士 卡達 鋼筆墨水"),BA.numberCast(int.class, 45));
 BA.debugLineNum = 132;BA.debugLine="ary_str_ink_name(46) = \"美國 Monteverde USA 核心墨水\"";
Debug.ShouldStop(8);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("美國 Monteverde USA 核心墨水"),BA.numberCast(int.class, 46));
 BA.debugLineNum = 133;BA.debugLine="ary_str_ink_name(47) = \"美國 Monteverde 鋼筆清洗劑\"";
Debug.ShouldStop(16);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("美國 Monteverde 鋼筆清洗劑"),BA.numberCast(int.class, 47));
 BA.debugLineNum = 134;BA.debugLine="ary_str_ink_name(48) = \"義大利 Aurora 鋼筆墨水\"";
Debug.ShouldStop(32);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("義大利 Aurora 鋼筆墨水"),BA.numberCast(int.class, 48));
 BA.debugLineNum = 135;BA.debugLine="ary_str_ink_name(49) = \"臺灣 墨堤 墨水\"";
Debug.ShouldStop(64);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("臺灣 墨堤 墨水"),BA.numberCast(int.class, 49));
 BA.debugLineNum = 136;BA.debugLine="ary_str_ink_name(50) = \"臺灣 道具屋藍濃 墨水\"";
Debug.ShouldStop(128);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("臺灣 道具屋藍濃 墨水"),BA.numberCast(int.class, 50));
 BA.debugLineNum = 137;BA.debugLine="ary_str_ink_name(51) = \"臺灣 道具屋藍濃 限定色墨水\"";
Debug.ShouldStop(256);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("臺灣 道具屋藍濃 限定色墨水"),BA.numberCast(int.class, 51));
 BA.debugLineNum = 138;BA.debugLine="ary_str_ink_name(52) = \"臺灣 道具屋藍濃 防水墨水\"";
Debug.ShouldStop(512);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("臺灣 道具屋藍濃 防水墨水"),BA.numberCast(int.class, 52));
 BA.debugLineNum = 139;BA.debugLine="ary_str_ink_name(53) = \"英國 YARD-O-LED 墨水\"";
Debug.ShouldStop(1024);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("英國 YARD-O-LED 墨水"),BA.numberCast(int.class, 53));
 BA.debugLineNum = 140;BA.debugLine="ary_str_ink_name(54) = \"西華 鋼筆 墨水\"";
Debug.ShouldStop(2048);
main.mostCurrent._ary_str_ink_name.setArrayElement (BA.ObjectToString("西華 鋼筆 墨水"),BA.numberCast(int.class, 54));
 BA.debugLineNum = 142;BA.debugLine="ary_str_ink_price(0) = \"50ML 480元\"";
Debug.ShouldStop(8192);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 480元"),BA.numberCast(int.class, 0));
 BA.debugLineNum = 143;BA.debugLine="ary_str_ink_price(1) = \"50ML 550元\"";
Debug.ShouldStop(16384);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 550元"),BA.numberCast(int.class, 1));
 BA.debugLineNum = 144;BA.debugLine="ary_str_ink_price(2) = \"50ML 440元\"";
Debug.ShouldStop(32768);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 440元"),BA.numberCast(int.class, 2));
 BA.debugLineNum = 145;BA.debugLine="ary_str_ink_price(3) = \"80ML 300元\"";
Debug.ShouldStop(65536);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("80ML 300元"),BA.numberCast(int.class, 3));
 BA.debugLineNum = 146;BA.debugLine="ary_str_ink_price(4) = \"40ML 325元\"";
Debug.ShouldStop(131072);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("40ML 325元"),BA.numberCast(int.class, 4));
 BA.debugLineNum = 147;BA.debugLine="ary_str_ink_price(5) = \"30ML 270元\"";
Debug.ShouldStop(262144);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("30ML 270元"),BA.numberCast(int.class, 5));
 BA.debugLineNum = 148;BA.debugLine="ary_str_ink_price(6) = \"60ML 200元\"";
Debug.ShouldStop(524288);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("60ML 200元"),BA.numberCast(int.class, 6));
 BA.debugLineNum = 149;BA.debugLine="ary_str_ink_price(7) = \"60ML 220元\"";
Debug.ShouldStop(1048576);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("60ML 220元"),BA.numberCast(int.class, 7));
 BA.debugLineNum = 150;BA.debugLine="ary_str_ink_price(8) = \"15ML 220元\"";
Debug.ShouldStop(2097152);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("15ML 220元"),BA.numberCast(int.class, 8));
 BA.debugLineNum = 151;BA.debugLine="ary_str_ink_price(9) = \"30ML 300元\"";
Debug.ShouldStop(4194304);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("30ML 300元"),BA.numberCast(int.class, 9));
 BA.debugLineNum = 152;BA.debugLine="ary_str_ink_price(10) = \"62.5ML 350元\"";
Debug.ShouldStop(8388608);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("62.5ML 350元"),BA.numberCast(int.class, 10));
 BA.debugLineNum = 153;BA.debugLine="ary_str_ink_price(11) = \"50ML 350元\"";
Debug.ShouldStop(16777216);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 350元"),BA.numberCast(int.class, 11));
 BA.debugLineNum = 154;BA.debugLine="ary_str_ink_price(12) = \"50ML 350元\"";
Debug.ShouldStop(33554432);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 350元"),BA.numberCast(int.class, 12));
 BA.debugLineNum = 155;BA.debugLine="ary_str_ink_price(13) = \"50ML 300元\"";
Debug.ShouldStop(67108864);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 300元"),BA.numberCast(int.class, 13));
 BA.debugLineNum = 156;BA.debugLine="ary_str_ink_price(14) = \"50ML 450元\"";
Debug.ShouldStop(134217728);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 450元"),BA.numberCast(int.class, 14));
 BA.debugLineNum = 157;BA.debugLine="ary_str_ink_price(15) = \"50ML 700元\"";
Debug.ShouldStop(268435456);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 700元"),BA.numberCast(int.class, 15));
 BA.debugLineNum = 158;BA.debugLine="ary_str_ink_price(16) = \"100ML 400元\"";
Debug.ShouldStop(536870912);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("100ML 400元"),BA.numberCast(int.class, 16));
 BA.debugLineNum = 159;BA.debugLine="ary_str_ink_price(17) = \"35ML 550元\"";
Debug.ShouldStop(1073741824);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("35ML 550元"),BA.numberCast(int.class, 17));
 BA.debugLineNum = 160;BA.debugLine="ary_str_ink_price(18) = \"60ML 550元\"";
Debug.ShouldStop(-2147483648);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("60ML 550元"),BA.numberCast(int.class, 18));
 BA.debugLineNum = 161;BA.debugLine="ary_str_ink_price(19) = \"60ML 600元\"";
Debug.ShouldStop(1);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("60ML 600元"),BA.numberCast(int.class, 19));
 BA.debugLineNum = 162;BA.debugLine="ary_str_ink_price(20) = \"75ML 960元\"";
Debug.ShouldStop(2);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("75ML 960元"),BA.numberCast(int.class, 20));
 BA.debugLineNum = 163;BA.debugLine="ary_str_ink_price(21) = \"35ML 450元\"";
Debug.ShouldStop(4);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("35ML 450元"),BA.numberCast(int.class, 21));
 BA.debugLineNum = 164;BA.debugLine="ary_str_ink_price(22) = \"35ML 500元\"";
Debug.ShouldStop(8);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("35ML 500元"),BA.numberCast(int.class, 22));
 BA.debugLineNum = 165;BA.debugLine="ary_str_ink_price(23) = \"35ML 650元\"";
Debug.ShouldStop(16);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("35ML 650元"),BA.numberCast(int.class, 23));
 BA.debugLineNum = 166;BA.debugLine="ary_str_ink_price(24) = \"62.5ML 240元\"";
Debug.ShouldStop(32);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("62.5ML 240元"),BA.numberCast(int.class, 24));
 BA.debugLineNum = 167;BA.debugLine="ary_str_ink_price(25) = \"30ML 240元\"";
Debug.ShouldStop(64);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("30ML 240元"),BA.numberCast(int.class, 25));
 BA.debugLineNum = 168;BA.debugLine="ary_str_ink_price(26) = \"50ML 490元\"";
Debug.ShouldStop(128);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 490元"),BA.numberCast(int.class, 26));
 BA.debugLineNum = 169;BA.debugLine="ary_str_ink_price(27) = \"60ML 630元\"";
Debug.ShouldStop(256);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("60ML 630元"),BA.numberCast(int.class, 27));
 BA.debugLineNum = 170;BA.debugLine="ary_str_ink_price(28) = \"60ML 300元\"";
Debug.ShouldStop(512);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("60ML 300元"),BA.numberCast(int.class, 28));
 BA.debugLineNum = 171;BA.debugLine="ary_str_ink_price(29) = \"50ML 300元\"";
Debug.ShouldStop(1024);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 300元"),BA.numberCast(int.class, 29));
 BA.debugLineNum = 172;BA.debugLine="ary_str_ink_price(30) = \"60ML 400元\"";
Debug.ShouldStop(2048);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("60ML 400元"),BA.numberCast(int.class, 30));
 BA.debugLineNum = 173;BA.debugLine="ary_str_ink_price(31) = \"60ML 300元\"";
Debug.ShouldStop(4096);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("60ML 300元"),BA.numberCast(int.class, 31));
 BA.debugLineNum = 174;BA.debugLine="ary_str_ink_price(32) = \"50ML 300元\"";
Debug.ShouldStop(8192);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 300元"),BA.numberCast(int.class, 32));
 BA.debugLineNum = 175;BA.debugLine="ary_str_ink_price(33) = \"30ML 450元\"";
Debug.ShouldStop(16384);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("30ML 450元"),BA.numberCast(int.class, 33));
 BA.debugLineNum = 176;BA.debugLine="ary_str_ink_price(34) = \"50ML 300元\"";
Debug.ShouldStop(32768);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 300元"),BA.numberCast(int.class, 34));
 BA.debugLineNum = 177;BA.debugLine="ary_str_ink_price(35) = \"20ML 250元\"";
Debug.ShouldStop(65536);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("20ML 250元"),BA.numberCast(int.class, 35));
 BA.debugLineNum = 178;BA.debugLine="ary_str_ink_price(36) = \"20ML 280元\"";
Debug.ShouldStop(131072);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("20ML 280元"),BA.numberCast(int.class, 36));
 BA.debugLineNum = 179;BA.debugLine="ary_str_ink_price(37) = \"50ML 500元\"";
Debug.ShouldStop(262144);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 500元"),BA.numberCast(int.class, 37));
 BA.debugLineNum = 180;BA.debugLine="ary_str_ink_price(38) = \"40ML 550元\"";
Debug.ShouldStop(524288);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("40ML 550元"),BA.numberCast(int.class, 38));
 BA.debugLineNum = 181;BA.debugLine="ary_str_ink_price(39) = \"40ML 550元\"";
Debug.ShouldStop(1048576);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("40ML 550元"),BA.numberCast(int.class, 39));
 BA.debugLineNum = 182;BA.debugLine="ary_str_ink_price(40) = \"40ML 650元\"";
Debug.ShouldStop(2097152);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("40ML 650元"),BA.numberCast(int.class, 40));
 BA.debugLineNum = 183;BA.debugLine="ary_str_ink_price(41) = \"50ML 650元\"";
Debug.ShouldStop(4194304);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 650元"),BA.numberCast(int.class, 41));
 BA.debugLineNum = 184;BA.debugLine="ary_str_ink_price(42) = \"50ML 800元\"";
Debug.ShouldStop(8388608);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 800元"),BA.numberCast(int.class, 42));
 BA.debugLineNum = 185;BA.debugLine="ary_str_ink_price(43) = \"30ML 300元\"";
Debug.ShouldStop(16777216);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("30ML 300元"),BA.numberCast(int.class, 43));
 BA.debugLineNum = 186;BA.debugLine="ary_str_ink_price(44) = \"50ML 600元\"";
Debug.ShouldStop(33554432);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 600元"),BA.numberCast(int.class, 44));
 BA.debugLineNum = 187;BA.debugLine="ary_str_ink_price(45) = \"50ML 945元\"";
Debug.ShouldStop(67108864);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 945元"),BA.numberCast(int.class, 45));
 BA.debugLineNum = 188;BA.debugLine="ary_str_ink_price(46) = \"90ML 368元\"";
Debug.ShouldStop(134217728);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("90ML 368元"),BA.numberCast(int.class, 46));
 BA.debugLineNum = 189;BA.debugLine="ary_str_ink_price(47) = \"480ML 576元\"";
Debug.ShouldStop(268435456);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("480ML 576元"),BA.numberCast(int.class, 47));
 BA.debugLineNum = 190;BA.debugLine="ary_str_ink_price(48) = \"45ML 360元\"";
Debug.ShouldStop(536870912);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("45ML 360元"),BA.numberCast(int.class, 48));
 BA.debugLineNum = 191;BA.debugLine="ary_str_ink_price(49) = \"20ML 220元\"";
Debug.ShouldStop(1073741824);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("20ML 220元"),BA.numberCast(int.class, 49));
 BA.debugLineNum = 192;BA.debugLine="ary_str_ink_price(50) = \"30ML 200元\"";
Debug.ShouldStop(-2147483648);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("30ML 200元"),BA.numberCast(int.class, 50));
 BA.debugLineNum = 193;BA.debugLine="ary_str_ink_price(51) = \"30ML 250元\"";
Debug.ShouldStop(1);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("30ML 250元"),BA.numberCast(int.class, 51));
 BA.debugLineNum = 194;BA.debugLine="ary_str_ink_price(52) = \"30ML 230元\"";
Debug.ShouldStop(2);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("30ML 230元"),BA.numberCast(int.class, 52));
 BA.debugLineNum = 195;BA.debugLine="ary_str_ink_price(53) = \"28.4ML 280元\"";
Debug.ShouldStop(4);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("28.4ML 280元"),BA.numberCast(int.class, 53));
 BA.debugLineNum = 196;BA.debugLine="ary_str_ink_price(54) = \"50ML 190元\"";
Debug.ShouldStop(8);
main.mostCurrent._ary_str_ink_price.setArrayElement (BA.ObjectToString("50ML 190元"),BA.numberCast(int.class, 54));
 BA.debugLineNum = 198;BA.debugLine="ary_dbl_ink_value(0) = 9.6";
Debug.ShouldStop(32);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 9.6),BA.numberCast(int.class, 0));
 BA.debugLineNum = 199;BA.debugLine="ary_dbl_ink_value(1) = 11";
Debug.ShouldStop(64);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 11),BA.numberCast(int.class, 1));
 BA.debugLineNum = 200;BA.debugLine="ary_dbl_ink_value(2) = 8.8";
Debug.ShouldStop(128);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 8.8),BA.numberCast(int.class, 2));
 BA.debugLineNum = 201;BA.debugLine="ary_dbl_ink_value(3) = 3.75";
Debug.ShouldStop(256);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 3.75),BA.numberCast(int.class, 3));
 BA.debugLineNum = 202;BA.debugLine="ary_dbl_ink_value(4) = 8.125";
Debug.ShouldStop(512);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 8.125),BA.numberCast(int.class, 4));
 BA.debugLineNum = 203;BA.debugLine="ary_dbl_ink_value(5) = 9";
Debug.ShouldStop(1024);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 9),BA.numberCast(int.class, 5));
 BA.debugLineNum = 204;BA.debugLine="ary_dbl_ink_value(6) = 3.33";
Debug.ShouldStop(2048);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 3.33),BA.numberCast(int.class, 6));
 BA.debugLineNum = 205;BA.debugLine="ary_dbl_ink_value(7) = 3.66";
Debug.ShouldStop(4096);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 3.66),BA.numberCast(int.class, 7));
 BA.debugLineNum = 206;BA.debugLine="ary_dbl_ink_value(8) = 14.66";
Debug.ShouldStop(8192);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 14.66),BA.numberCast(int.class, 8));
 BA.debugLineNum = 207;BA.debugLine="ary_dbl_ink_value(9) = 10";
Debug.ShouldStop(16384);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 10),BA.numberCast(int.class, 9));
 BA.debugLineNum = 208;BA.debugLine="ary_dbl_ink_value(10) = 5.6";
Debug.ShouldStop(32768);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 5.6),BA.numberCast(int.class, 10));
 BA.debugLineNum = 209;BA.debugLine="ary_dbl_ink_value(11) = 7";
Debug.ShouldStop(65536);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 7),BA.numberCast(int.class, 11));
 BA.debugLineNum = 210;BA.debugLine="ary_dbl_ink_value(12) = 7";
Debug.ShouldStop(131072);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 7),BA.numberCast(int.class, 12));
 BA.debugLineNum = 211;BA.debugLine="ary_dbl_ink_value(13) = 6";
Debug.ShouldStop(262144);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 6),BA.numberCast(int.class, 13));
 BA.debugLineNum = 212;BA.debugLine="ary_dbl_ink_value(14) = 9";
Debug.ShouldStop(524288);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 9),BA.numberCast(int.class, 14));
 BA.debugLineNum = 213;BA.debugLine="ary_dbl_ink_value(15) = 9";
Debug.ShouldStop(1048576);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 9),BA.numberCast(int.class, 15));
 BA.debugLineNum = 214;BA.debugLine="ary_dbl_ink_value(16) = 4";
Debug.ShouldStop(2097152);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 4),BA.numberCast(int.class, 16));
 BA.debugLineNum = 215;BA.debugLine="ary_dbl_ink_value(17) = 15.71";
Debug.ShouldStop(4194304);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 15.71),BA.numberCast(int.class, 17));
 BA.debugLineNum = 216;BA.debugLine="ary_dbl_ink_value(18) = 9.16";
Debug.ShouldStop(8388608);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 9.16),BA.numberCast(int.class, 18));
 BA.debugLineNum = 217;BA.debugLine="ary_dbl_ink_value(19) = 10";
Debug.ShouldStop(16777216);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 10),BA.numberCast(int.class, 19));
 BA.debugLineNum = 218;BA.debugLine="ary_dbl_ink_value(20) = 12.8";
Debug.ShouldStop(33554432);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 12.8),BA.numberCast(int.class, 20));
 BA.debugLineNum = 219;BA.debugLine="ary_dbl_ink_value(21) = 12.86";
Debug.ShouldStop(67108864);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 12.86),BA.numberCast(int.class, 21));
 BA.debugLineNum = 220;BA.debugLine="ary_dbl_ink_value(22) = 14.29";
Debug.ShouldStop(134217728);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 14.29),BA.numberCast(int.class, 22));
 BA.debugLineNum = 221;BA.debugLine="ary_dbl_ink_value(23) = 18.57";
Debug.ShouldStop(268435456);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 18.57),BA.numberCast(int.class, 23));
 BA.debugLineNum = 222;BA.debugLine="ary_dbl_ink_value(24) = 3.84";
Debug.ShouldStop(536870912);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 3.84),BA.numberCast(int.class, 24));
 BA.debugLineNum = 223;BA.debugLine="ary_dbl_ink_value(25) = 8";
Debug.ShouldStop(1073741824);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 8),BA.numberCast(int.class, 25));
 BA.debugLineNum = 224;BA.debugLine="ary_dbl_ink_value(26) = 9.8";
Debug.ShouldStop(-2147483648);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 9.8),BA.numberCast(int.class, 26));
 BA.debugLineNum = 225;BA.debugLine="ary_dbl_ink_value(27) = 10.5";
Debug.ShouldStop(1);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 10.5),BA.numberCast(int.class, 27));
 BA.debugLineNum = 226;BA.debugLine="ary_dbl_ink_value(28) = 5";
Debug.ShouldStop(2);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 5),BA.numberCast(int.class, 28));
 BA.debugLineNum = 227;BA.debugLine="ary_dbl_ink_value(29) = 6";
Debug.ShouldStop(4);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 6),BA.numberCast(int.class, 29));
 BA.debugLineNum = 228;BA.debugLine="ary_dbl_ink_value(30) = 6.66";
Debug.ShouldStop(8);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 6.66),BA.numberCast(int.class, 30));
 BA.debugLineNum = 229;BA.debugLine="ary_dbl_ink_value(31) = 5";
Debug.ShouldStop(16);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 5),BA.numberCast(int.class, 31));
 BA.debugLineNum = 230;BA.debugLine="ary_dbl_ink_value(32) = 6";
Debug.ShouldStop(32);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 6),BA.numberCast(int.class, 32));
 BA.debugLineNum = 231;BA.debugLine="ary_dbl_ink_value(33) = 15";
Debug.ShouldStop(64);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 15),BA.numberCast(int.class, 33));
 BA.debugLineNum = 232;BA.debugLine="ary_dbl_ink_value(34) = 6";
Debug.ShouldStop(128);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 6),BA.numberCast(int.class, 34));
 BA.debugLineNum = 233;BA.debugLine="ary_dbl_ink_value(35) = 12.5";
Debug.ShouldStop(256);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 12.5),BA.numberCast(int.class, 35));
 BA.debugLineNum = 234;BA.debugLine="ary_dbl_ink_value(36) = 14";
Debug.ShouldStop(512);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 14),BA.numberCast(int.class, 36));
 BA.debugLineNum = 235;BA.debugLine="ary_dbl_ink_value(37) = 10";
Debug.ShouldStop(1024);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 10),BA.numberCast(int.class, 37));
 BA.debugLineNum = 236;BA.debugLine="ary_dbl_ink_value(38) = 13.75";
Debug.ShouldStop(2048);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 13.75),BA.numberCast(int.class, 38));
 BA.debugLineNum = 237;BA.debugLine="ary_dbl_ink_value(39) = 13.75";
Debug.ShouldStop(4096);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 13.75),BA.numberCast(int.class, 39));
 BA.debugLineNum = 238;BA.debugLine="ary_dbl_ink_value(40) = 16.25";
Debug.ShouldStop(8192);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 16.25),BA.numberCast(int.class, 40));
 BA.debugLineNum = 239;BA.debugLine="ary_dbl_ink_value(41) = 13";
Debug.ShouldStop(16384);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 13),BA.numberCast(int.class, 41));
 BA.debugLineNum = 240;BA.debugLine="ary_dbl_ink_value(42) = 16";
Debug.ShouldStop(32768);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 16),BA.numberCast(int.class, 42));
 BA.debugLineNum = 241;BA.debugLine="ary_dbl_ink_value(43) = 10";
Debug.ShouldStop(65536);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 10),BA.numberCast(int.class, 43));
 BA.debugLineNum = 242;BA.debugLine="ary_dbl_ink_value(44) = 12";
Debug.ShouldStop(131072);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 12),BA.numberCast(int.class, 44));
 BA.debugLineNum = 243;BA.debugLine="ary_dbl_ink_value(45) = 18.9";
Debug.ShouldStop(262144);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 18.9),BA.numberCast(int.class, 45));
 BA.debugLineNum = 244;BA.debugLine="ary_dbl_ink_value(46) = 4";
Debug.ShouldStop(524288);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 4),BA.numberCast(int.class, 46));
 BA.debugLineNum = 245;BA.debugLine="ary_dbl_ink_value(47) = 1.2";
Debug.ShouldStop(1048576);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 1.2),BA.numberCast(int.class, 47));
 BA.debugLineNum = 246;BA.debugLine="ary_dbl_ink_value(48) = 8";
Debug.ShouldStop(2097152);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 8),BA.numberCast(int.class, 48));
 BA.debugLineNum = 247;BA.debugLine="ary_dbl_ink_value(49) = 11";
Debug.ShouldStop(4194304);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 11),BA.numberCast(int.class, 49));
 BA.debugLineNum = 248;BA.debugLine="ary_dbl_ink_value(50) = 6.66";
Debug.ShouldStop(8388608);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 6.66),BA.numberCast(int.class, 50));
 BA.debugLineNum = 249;BA.debugLine="ary_dbl_ink_value(51) = 8.33";
Debug.ShouldStop(16777216);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 8.33),BA.numberCast(int.class, 51));
 BA.debugLineNum = 250;BA.debugLine="ary_dbl_ink_value(52) = 7.66";
Debug.ShouldStop(33554432);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 7.66),BA.numberCast(int.class, 52));
 BA.debugLineNum = 251;BA.debugLine="ary_dbl_ink_value(53) = 9.86";
Debug.ShouldStop(67108864);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 9.86),BA.numberCast(int.class, 53));
 BA.debugLineNum = 252;BA.debugLine="ary_dbl_ink_value(54) = 3.8";
Debug.ShouldStop(134217728);
main._ary_dbl_ink_value.setArrayElement (BA.numberCast(double.class, 3.8),BA.numberCast(int.class, 54));
 BA.debugLineNum = 254;BA.debugLine="ary_str_profit_name(0) = \"10%\"";
Debug.ShouldStop(536870912);
main.mostCurrent._ary_str_profit_name.setArrayElement (BA.ObjectToString("10%"),BA.numberCast(int.class, 0));
 BA.debugLineNum = 255;BA.debugLine="ary_str_profit_name(1) = \"20%\"";
Debug.ShouldStop(1073741824);
main.mostCurrent._ary_str_profit_name.setArrayElement (BA.ObjectToString("20%"),BA.numberCast(int.class, 1));
 BA.debugLineNum = 256;BA.debugLine="ary_str_profit_name(2) = \"25%\"";
Debug.ShouldStop(-2147483648);
main.mostCurrent._ary_str_profit_name.setArrayElement (BA.ObjectToString("25%"),BA.numberCast(int.class, 2));
 BA.debugLineNum = 257;BA.debugLine="ary_str_profit_name(3) = \"30%\"";
Debug.ShouldStop(1);
main.mostCurrent._ary_str_profit_name.setArrayElement (BA.ObjectToString("30%"),BA.numberCast(int.class, 3));
 BA.debugLineNum = 259;BA.debugLine="ary_str_profit_unit(0) = \"玻璃瓶10元\"";
Debug.ShouldStop(4);
main.mostCurrent._ary_str_profit_unit.setArrayElement (BA.ObjectToString("玻璃瓶10元"),BA.numberCast(int.class, 0));
 BA.debugLineNum = 260;BA.debugLine="ary_str_profit_unit(1) = \"玻璃瓶10元\"";
Debug.ShouldStop(8);
main.mostCurrent._ary_str_profit_unit.setArrayElement (BA.ObjectToString("玻璃瓶10元"),BA.numberCast(int.class, 1));
 BA.debugLineNum = 261;BA.debugLine="ary_str_profit_unit(2) = \"玻璃瓶10元\"";
Debug.ShouldStop(16);
main.mostCurrent._ary_str_profit_unit.setArrayElement (BA.ObjectToString("玻璃瓶10元"),BA.numberCast(int.class, 2));
 BA.debugLineNum = 262;BA.debugLine="ary_str_profit_unit(3) = \"玻璃瓶10元\"";
Debug.ShouldStop(32);
main.mostCurrent._ary_str_profit_unit.setArrayElement (BA.ObjectToString("玻璃瓶10元"),BA.numberCast(int.class, 3));
 BA.debugLineNum = 264;BA.debugLine="ary_dbl_profit_value(0) = 1.1";
Debug.ShouldStop(128);
main._ary_dbl_profit_value.setArrayElement (BA.numberCast(double.class, 1.1),BA.numberCast(int.class, 0));
 BA.debugLineNum = 265;BA.debugLine="ary_dbl_profit_value(1) = 1.2";
Debug.ShouldStop(256);
main._ary_dbl_profit_value.setArrayElement (BA.numberCast(double.class, 1.2),BA.numberCast(int.class, 1));
 BA.debugLineNum = 266;BA.debugLine="ary_dbl_profit_value(2) = 1.25";
Debug.ShouldStop(512);
main._ary_dbl_profit_value.setArrayElement (BA.numberCast(double.class, 1.25),BA.numberCast(int.class, 2));
 BA.debugLineNum = 267;BA.debugLine="ary_dbl_profit_value(3) = 1.3";
Debug.ShouldStop(1024);
main._ary_dbl_profit_value.setArrayElement (BA.numberCast(double.class, 1.3),BA.numberCast(int.class, 3));
 BA.debugLineNum = 269;BA.debugLine="Button_clear_Click";
Debug.ShouldStop(4096);
_button_clear_click();
 BA.debugLineNum = 270;BA.debugLine="sub_ink_ml_menu_initial";
Debug.ShouldStop(8192);
_sub_ink_ml_menu_initial();
 BA.debugLineNum = 271;BA.debugLine="sub_ink_menu_initial";
Debug.ShouldStop(16384);
_sub_ink_menu_initial();
 BA.debugLineNum = 272;BA.debugLine="sub_profit_menu_initial";
Debug.ShouldStop(32768);
_sub_profit_menu_initial();
 BA.debugLineNum = 273;BA.debugLine="PanelMainMenu.Visible = True";
Debug.ShouldStop(65536);
main.mostCurrent._panelmainmenu.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 274;BA.debugLine="Panel_ink_ml.Visible = False";
Debug.ShouldStop(131072);
main.mostCurrent._panel_ink_ml.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 275;BA.debugLine="Panel_ink.Visible = False";
Debug.ShouldStop(262144);
main.mostCurrent._panel_ink.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 276;BA.debugLine="Panel_profit.Visible = False";
Debug.ShouldStop(524288);
main.mostCurrent._panel_profit.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 278;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,315);
if (RapidSub.canDelegate("activity_pause")) return b4a.example.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 315;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(67108864);
 BA.debugLineNum = 317;BA.debugLine="End Sub";
Debug.ShouldStop(268435456);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,311);
if (RapidSub.canDelegate("activity_resume")) return b4a.example.main.remoteMe.runUserSub(false, "main","activity_resume");
 BA.debugLineNum = 311;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(4194304);
 BA.debugLineNum = 313;BA.debugLine="End Sub";
Debug.ShouldStop(16777216);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button_bottle_click() throws Exception{
try {
		Debug.PushSubsStack("Button_bottle_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,356);
if (RapidSub.canDelegate("button_bottle_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","button_bottle_click");
 BA.debugLineNum = 356;BA.debugLine="Sub Button_bottle_Click";
Debug.ShouldStop(8);
 BA.debugLineNum = 358;BA.debugLine="If int_cal_result>0 And int_bottle>=1 Then";
Debug.ShouldStop(32);
if (RemoteObject.solveBoolean(">",main._int_cal_result,BA.numberCast(double.class, 0)) && RemoteObject.solveBoolean("g",main._int_bottle,BA.numberCast(double.class, 1))) { 
 BA.debugLineNum = 359;BA.debugLine="int_cal_result=Round(int_cal_result-(int_bottle*";
Debug.ShouldStop(64);
main._int_cal_result = BA.numberCast(int.class, main.mostCurrent.__c.runMethod(true,"Round",(Object)(BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._int_cal_result,(RemoteObject.solve(new RemoteObject[] {main._int_bottle,RemoteObject.createImmutable(10)}, "*",0, 1))}, "-",1, 1)))));
 }else {
 BA.debugLineNum = 361;BA.debugLine="Msgbox(\"無法折讓空瓶\",\"警告\")";
Debug.ShouldStop(256);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("無法折讓空瓶")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("警告"))),main.mostCurrent.activityBA);
 };
 BA.debugLineNum = 363;BA.debugLine="sub_update_menu";
Debug.ShouldStop(1024);
_sub_update_menu();
 BA.debugLineNum = 364;BA.debugLine="End Sub";
Debug.ShouldStop(2048);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button_clear_click() throws Exception{
try {
		Debug.PushSubsStack("Button_clear_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,332);
if (RapidSub.canDelegate("button_clear_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","button_clear_click");
 BA.debugLineNum = 332;BA.debugLine="Sub Button_clear_Click";
Debug.ShouldStop(2048);
 BA.debugLineNum = 334;BA.debugLine="int_select_ink_ml_index=cnt_default_ink_ml_index";
Debug.ShouldStop(8192);
main._int_select_ink_ml_index = main._cnt_default_ink_ml_index;
 BA.debugLineNum = 335;BA.debugLine="int_select_ink_index=cnt_default_ink_name_index";
Debug.ShouldStop(16384);
main._int_select_ink_index = main._cnt_default_ink_name_index;
 BA.debugLineNum = 336;BA.debugLine="int_select_profit_index=cnt_default_profit_name_i";
Debug.ShouldStop(32768);
main._int_select_profit_index = main._cnt_default_profit_name_index;
 BA.debugLineNum = 337;BA.debugLine="int_cal_result=0";
Debug.ShouldStop(65536);
main._int_cal_result = BA.numberCast(int.class, 0);
 BA.debugLineNum = 338;BA.debugLine="int_bottle=0";
Debug.ShouldStop(131072);
main._int_bottle = BA.numberCast(int.class, 0);
 BA.debugLineNum = 339;BA.debugLine="sub_update_menu";
Debug.ShouldStop(262144);
_sub_update_menu();
 BA.debugLineNum = 340;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button_ink_ml_click() throws Exception{
try {
		Debug.PushSubsStack("Button_ink_ml_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,320);
if (RapidSub.canDelegate("button_ink_ml_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","button_ink_ml_click");
 BA.debugLineNum = 320;BA.debugLine="Sub Button_ink_ml_Click";
Debug.ShouldStop(-2147483648);
 BA.debugLineNum = 321;BA.debugLine="Panel_ink_ml.Visible = True";
Debug.ShouldStop(1);
main.mostCurrent._panel_ink_ml.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 322;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button_ink_price_click() throws Exception{
try {
		Debug.PushSubsStack("Button_ink_price_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,324);
if (RapidSub.canDelegate("button_ink_price_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","button_ink_price_click");
 BA.debugLineNum = 324;BA.debugLine="Sub Button_ink_price_Click";
Debug.ShouldStop(8);
 BA.debugLineNum = 325;BA.debugLine="Panel_ink.Visible = True";
Debug.ShouldStop(16);
main.mostCurrent._panel_ink.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 326;BA.debugLine="End Sub";
Debug.ShouldStop(32);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button_one_bottle_click() throws Exception{
try {
		Debug.PushSubsStack("Button_one_bottle_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,366);
if (RapidSub.canDelegate("button_one_bottle_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","button_one_bottle_click");
 BA.debugLineNum = 366;BA.debugLine="Sub Button_one_bottle_Click";
Debug.ShouldStop(8192);
 BA.debugLineNum = 368;BA.debugLine="If int_cal_result>0 Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean(">",main._int_cal_result,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 369;BA.debugLine="int_cal_result=int_cal_result-10";
Debug.ShouldStop(65536);
main._int_cal_result = RemoteObject.solve(new RemoteObject[] {main._int_cal_result,RemoteObject.createImmutable(10)}, "-",1, 1);
 }else {
 BA.debugLineNum = 371;BA.debugLine="Msgbox(\"沒有餘額，無法折讓空瓶\",\"警告\")";
Debug.ShouldStop(262144);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("沒有餘額，無法折讓空瓶")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("警告"))),main.mostCurrent.activityBA);
 };
 BA.debugLineNum = 373;BA.debugLine="sub_update_menu";
Debug.ShouldStop(1048576);
_sub_update_menu();
 BA.debugLineNum = 374;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button_profit_click() throws Exception{
try {
		Debug.PushSubsStack("Button_profit_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,328);
if (RapidSub.canDelegate("button_profit_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","button_profit_click");
 BA.debugLineNum = 328;BA.debugLine="Sub Button_profit_Click";
Debug.ShouldStop(128);
 BA.debugLineNum = 329;BA.debugLine="Panel_profit.Visible = True";
Debug.ShouldStop(256);
main.mostCurrent._panel_profit.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 330;BA.debugLine="End Sub";
Debug.ShouldStop(512);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button_single_calculation_click() throws Exception{
try {
		Debug.PushSubsStack("Button_single_calculation_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,342);
if (RapidSub.canDelegate("button_single_calculation_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","button_single_calculation_click");
 BA.debugLineNum = 342;BA.debugLine="Sub Button_single_calculation_Click";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 344;BA.debugLine="int_bottle=1";
Debug.ShouldStop(8388608);
main._int_bottle = BA.numberCast(int.class, 1);
 BA.debugLineNum = 345;BA.debugLine="int_cal_result=Round((ary_int_ink_ml_value(int_se";
Debug.ShouldStop(16777216);
main._int_cal_result = BA.numberCast(int.class, main.mostCurrent.__c.runMethod(true,"Round",(Object)((RemoteObject.solve(new RemoteObject[] {main._ary_int_ink_ml_value.getArrayElement(true,main._int_select_ink_ml_index),main._ary_dbl_ink_value.getArrayElement(true,main._int_select_ink_index),main._ary_dbl_profit_value.getArrayElement(true,main._int_select_profit_index),RemoteObject.createImmutable(10)}, "**+",1, 0)))));
 BA.debugLineNum = 346;BA.debugLine="sub_update_menu";
Debug.ShouldStop(33554432);
_sub_update_menu();
 BA.debugLineNum = 347;BA.debugLine="End Sub";
Debug.ShouldStop(67108864);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button_total_calculation_click() throws Exception{
try {
		Debug.PushSubsStack("Button_total_calculation_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,349);
if (RapidSub.canDelegate("button_total_calculation_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","button_total_calculation_click");
 BA.debugLineNum = 349;BA.debugLine="Sub Button_total_calculation_Click";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 351;BA.debugLine="int_cal_result=int_cal_result+Round((ary_int_ink_";
Debug.ShouldStop(1073741824);
main._int_cal_result = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {main._int_cal_result,main.mostCurrent.__c.runMethod(true,"Round",(Object)((RemoteObject.solve(new RemoteObject[] {main._ary_int_ink_ml_value.getArrayElement(true,main._int_select_ink_ml_index),main._ary_dbl_ink_value.getArrayElement(true,main._int_select_ink_index),main._ary_dbl_profit_value.getArrayElement(true,main._int_select_profit_index),RemoteObject.createImmutable(10)}, "**+",1, 0))))}, "+",1, 2));
 BA.debugLineNum = 352;BA.debugLine="int_bottle=int_bottle+1";
Debug.ShouldStop(-2147483648);
main._int_bottle = RemoteObject.solve(new RemoteObject[] {main._int_bottle,RemoteObject.createImmutable(1)}, "+",1, 1);
 BA.debugLineNum = 353;BA.debugLine="sub_update_menu";
Debug.ShouldStop(1);
_sub_update_menu();
 BA.debugLineNum = 354;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 25;BA.debugLine="Private PanelMainMenu As Panel";
main.mostCurrent._panelmainmenu = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 26;BA.debugLine="Private Button_ink_ml As Button";
main.mostCurrent._button_ink_ml = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 27;BA.debugLine="Private Button_ink_price As Button";
main.mostCurrent._button_ink_price = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 28;BA.debugLine="Private Button_profit As Button";
main.mostCurrent._button_profit = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 29;BA.debugLine="Private Button_clear As Button";
main.mostCurrent._button_clear = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 30;BA.debugLine="Private Button_single_calculation As Button";
main.mostCurrent._button_single_calculation = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 31;BA.debugLine="Private Button_total_calculation As Button";
main.mostCurrent._button_total_calculation = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 32;BA.debugLine="Private Button_bottle As Button";
main.mostCurrent._button_bottle = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 33;BA.debugLine="Private Button_one_bottle As Button";
main.mostCurrent._button_one_bottle = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 34;BA.debugLine="Private EditTextResult As EditText";
main.mostCurrent._edittextresult = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 35;BA.debugLine="Private Label_ink_ml As Label";
main.mostCurrent._label_ink_ml = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 36;BA.debugLine="Private Label_ink_name As Label";
main.mostCurrent._label_ink_name = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 37;BA.debugLine="Private Label_ink_price As Label";
main.mostCurrent._label_ink_price = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 38;BA.debugLine="Private Label_profit_name As Label";
main.mostCurrent._label_profit_name = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 39;BA.debugLine="Private Label_profit_unit As Label";
main.mostCurrent._label_profit_unit = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 40;BA.debugLine="Private Panel_ink_ml As Panel";
main.mostCurrent._panel_ink_ml = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 41;BA.debugLine="Private ListView_ink_ml As ListView";
main.mostCurrent._listview_ink_ml = RemoteObject.createNew ("anywheresoftware.b4a.objects.ListViewWrapper");
 //BA.debugLineNum = 42;BA.debugLine="Private Panel_ink As Panel";
main.mostCurrent._panel_ink = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 43;BA.debugLine="Private ListView_ink As ListView";
main.mostCurrent._listview_ink = RemoteObject.createNew ("anywheresoftware.b4a.objects.ListViewWrapper");
 //BA.debugLineNum = 44;BA.debugLine="Private Panel_profit As Panel";
main.mostCurrent._panel_profit = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 45;BA.debugLine="Private ListView_profit As ListView";
main.mostCurrent._listview_profit = RemoteObject.createNew ("anywheresoftware.b4a.objects.ListViewWrapper");
 //BA.debugLineNum = 47;BA.debugLine="Dim const cnt_default_ink_ml_index=0, cnt_default";
main._cnt_default_ink_ml_index = BA.numberCast(int.class, 0);
main._cnt_default_ink_name_index = BA.numberCast(int.class, 0);
main._cnt_default_profit_name_index = BA.numberCast(int.class, 0);
 //BA.debugLineNum = 48;BA.debugLine="Dim const cnt_int_ink_ml_array_size=5 As Int";
main._cnt_int_ink_ml_array_size = BA.numberCast(int.class, 5);
 //BA.debugLineNum = 49;BA.debugLine="Dim const cnt_int_ink_array_size=55 As Int";
main._cnt_int_ink_array_size = BA.numberCast(int.class, 55);
 //BA.debugLineNum = 50;BA.debugLine="Dim const cnt_int_profit_array_size=4 As Int";
main._cnt_int_profit_array_size = BA.numberCast(int.class, 4);
 //BA.debugLineNum = 52;BA.debugLine="Dim ary_str_ink_ml_name(cnt_int_ink_ml_array_size";
main.mostCurrent._ary_str_ink_ml_name = RemoteObject.createNewArray ("String", new int[] {main._cnt_int_ink_ml_array_size.<Integer>get().intValue()}, new Object[]{});
 //BA.debugLineNum = 53;BA.debugLine="Dim ary_int_ink_ml_value(cnt_int_ink_ml_array_siz";
main._ary_int_ink_ml_value = RemoteObject.createNewArray ("int", new int[] {main._cnt_int_ink_ml_array_size.<Integer>get().intValue()}, new Object[]{});
 //BA.debugLineNum = 54;BA.debugLine="Dim ary_str_ink_name(cnt_int_ink_array_size) As S";
main.mostCurrent._ary_str_ink_name = RemoteObject.createNewArray ("String", new int[] {main._cnt_int_ink_array_size.<Integer>get().intValue()}, new Object[]{});
 //BA.debugLineNum = 55;BA.debugLine="Dim ary_str_ink_price(cnt_int_ink_array_size) As";
main.mostCurrent._ary_str_ink_price = RemoteObject.createNewArray ("String", new int[] {main._cnt_int_ink_array_size.<Integer>get().intValue()}, new Object[]{});
 //BA.debugLineNum = 56;BA.debugLine="Dim ary_dbl_ink_value(cnt_int_ink_array_size) As";
main._ary_dbl_ink_value = RemoteObject.createNewArray ("double", new int[] {main._cnt_int_ink_array_size.<Integer>get().intValue()}, new Object[]{});
 //BA.debugLineNum = 57;BA.debugLine="Dim ary_str_profit_name(cnt_int_profit_array_size";
main.mostCurrent._ary_str_profit_name = RemoteObject.createNewArray ("String", new int[] {main._cnt_int_profit_array_size.<Integer>get().intValue()}, new Object[]{});
 //BA.debugLineNum = 58;BA.debugLine="Dim ary_str_profit_unit(cnt_int_profit_array_size";
main.mostCurrent._ary_str_profit_unit = RemoteObject.createNewArray ("String", new int[] {main._cnt_int_profit_array_size.<Integer>get().intValue()}, new Object[]{});
 //BA.debugLineNum = 59;BA.debugLine="Dim ary_dbl_profit_value(cnt_int_profit_array_siz";
main._ary_dbl_profit_value = RemoteObject.createNewArray ("double", new int[] {main._cnt_int_profit_array_size.<Integer>get().intValue()}, new Object[]{});
 //BA.debugLineNum = 61;BA.debugLine="Dim int_select_ink_ml_index=0 As Int	'目前墨水容量選項";
main._int_select_ink_ml_index = BA.numberCast(int.class, 0);
 //BA.debugLineNum = 62;BA.debugLine="Dim int_select_ink_index=0 As Int		'目前墨水選項";
main._int_select_ink_index = BA.numberCast(int.class, 0);
 //BA.debugLineNum = 63;BA.debugLine="Dim int_select_profit_index=0 As Int	'目前利潤選項";
main._int_select_profit_index = BA.numberCast(int.class, 0);
 //BA.debugLineNum = 64;BA.debugLine="Dim int_bottle=0 As Int					'目前累積折讓空瓶數量";
main._int_bottle = BA.numberCast(int.class, 0);
 //BA.debugLineNum = 65;BA.debugLine="Dim int_cal_result=0 As Int				'計算結果";
main._int_cal_result = BA.numberCast(int.class, 0);
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _listview_ink_itemclick(RemoteObject _position,RemoteObject _value) throws Exception{
try {
		Debug.PushSubsStack("ListView_ink_ItemClick (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,386);
if (RapidSub.canDelegate("listview_ink_itemclick")) return b4a.example.main.remoteMe.runUserSub(false, "main","listview_ink_itemclick", _position, _value);
Debug.locals.put("Position", _position);
Debug.locals.put("Value", _value);
 BA.debugLineNum = 386;BA.debugLine="Sub ListView_ink_ItemClick (Position As Int, Value";
Debug.ShouldStop(2);
 BA.debugLineNum = 387;BA.debugLine="int_select_ink_index=Position";
Debug.ShouldStop(4);
main._int_select_ink_index = _position;
 BA.debugLineNum = 388;BA.debugLine="sub_update_menu";
Debug.ShouldStop(8);
_sub_update_menu();
 BA.debugLineNum = 390;BA.debugLine="PanelMainMenu.Visible = True";
Debug.ShouldStop(32);
main.mostCurrent._panelmainmenu.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 391;BA.debugLine="Panel_ink_ml.Visible = False";
Debug.ShouldStop(64);
main.mostCurrent._panel_ink_ml.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 392;BA.debugLine="Panel_ink.Visible = False";
Debug.ShouldStop(128);
main.mostCurrent._panel_ink.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 393;BA.debugLine="Panel_profit.Visible = False";
Debug.ShouldStop(256);
main.mostCurrent._panel_profit.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 394;BA.debugLine="End Sub";
Debug.ShouldStop(512);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _listview_ink_ml_itemclick(RemoteObject _position,RemoteObject _value) throws Exception{
try {
		Debug.PushSubsStack("ListView_ink_ml_ItemClick (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,376);
if (RapidSub.canDelegate("listview_ink_ml_itemclick")) return b4a.example.main.remoteMe.runUserSub(false, "main","listview_ink_ml_itemclick", _position, _value);
Debug.locals.put("Position", _position);
Debug.locals.put("Value", _value);
 BA.debugLineNum = 376;BA.debugLine="Sub ListView_ink_ml_ItemClick (Position As Int, Va";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 377;BA.debugLine="int_select_ink_ml_index=Position";
Debug.ShouldStop(16777216);
main._int_select_ink_ml_index = _position;
 BA.debugLineNum = 378;BA.debugLine="sub_update_menu";
Debug.ShouldStop(33554432);
_sub_update_menu();
 BA.debugLineNum = 380;BA.debugLine="PanelMainMenu.Visible = True";
Debug.ShouldStop(134217728);
main.mostCurrent._panelmainmenu.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 381;BA.debugLine="Panel_ink_ml.Visible = False";
Debug.ShouldStop(268435456);
main.mostCurrent._panel_ink_ml.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 382;BA.debugLine="Panel_ink.Visible = False";
Debug.ShouldStop(536870912);
main.mostCurrent._panel_ink.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 383;BA.debugLine="Panel_profit.Visible = False";
Debug.ShouldStop(1073741824);
main.mostCurrent._panel_profit.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 384;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _listview_profit_itemclick(RemoteObject _position,RemoteObject _value) throws Exception{
try {
		Debug.PushSubsStack("ListView_profit_ItemClick (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,396);
if (RapidSub.canDelegate("listview_profit_itemclick")) return b4a.example.main.remoteMe.runUserSub(false, "main","listview_profit_itemclick", _position, _value);
Debug.locals.put("Position", _position);
Debug.locals.put("Value", _value);
 BA.debugLineNum = 396;BA.debugLine="Sub ListView_profit_ItemClick (Position As Int, Va";
Debug.ShouldStop(2048);
 BA.debugLineNum = 397;BA.debugLine="int_select_profit_index=Position";
Debug.ShouldStop(4096);
main._int_select_profit_index = _position;
 BA.debugLineNum = 398;BA.debugLine="sub_update_menu";
Debug.ShouldStop(8192);
_sub_update_menu();
 BA.debugLineNum = 400;BA.debugLine="PanelMainMenu.Visible = True";
Debug.ShouldStop(32768);
main.mostCurrent._panelmainmenu.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 401;BA.debugLine="Panel_ink_ml.Visible = False";
Debug.ShouldStop(65536);
main.mostCurrent._panel_ink_ml.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 402;BA.debugLine="Panel_ink.Visible = False";
Debug.ShouldStop(131072);
main.mostCurrent._panel_ink.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 403;BA.debugLine="Panel_profit.Visible = False";
Debug.ShouldStop(262144);
main.mostCurrent._panel_profit.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 404;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("b4a.example.main");
starter.myClass = BA.getDeviceClass ("b4a.example.starter");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _sub_ink_menu_initial() throws Exception{
try {
		Debug.PushSubsStack("sub_ink_menu_initial (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,298);
if (RapidSub.canDelegate("sub_ink_menu_initial")) return b4a.example.main.remoteMe.runUserSub(false, "main","sub_ink_menu_initial");
int _i = 0;
 BA.debugLineNum = 298;BA.debugLine="Sub sub_ink_menu_initial";
Debug.ShouldStop(512);
 BA.debugLineNum = 299;BA.debugLine="For i = 0 To (cnt_int_ink_array_size-1)";
Debug.ShouldStop(1024);
{
final int step1 = 1;
final int limit1 = (RemoteObject.solve(new RemoteObject[] {main._cnt_int_ink_array_size,RemoteObject.createImmutable(1)}, "-",1, 1)).<Integer>get().intValue();
_i = 0 ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 300;BA.debugLine="ListView_ink.AddTwoLines2(ary_str_ink_name(i),ar";
Debug.ShouldStop(2048);
main.mostCurrent._listview_ink.runVoidMethod ("AddTwoLines2",(Object)(BA.ObjectToCharSequence(main.mostCurrent._ary_str_ink_name.getArrayElement(true,BA.numberCast(int.class, _i)))),(Object)(BA.ObjectToCharSequence(main.mostCurrent._ary_str_ink_price.getArrayElement(true,BA.numberCast(int.class, _i)))),(Object)((main._ary_dbl_ink_value.getArrayElement(true,BA.numberCast(int.class, _i)))));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 302;BA.debugLine="End Sub";
Debug.ShouldStop(8192);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _sub_ink_ml_menu_initial() throws Exception{
try {
		Debug.PushSubsStack("sub_ink_ml_menu_initial (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,291);
if (RapidSub.canDelegate("sub_ink_ml_menu_initial")) return b4a.example.main.remoteMe.runUserSub(false, "main","sub_ink_ml_menu_initial");
int _i = 0;
 BA.debugLineNum = 291;BA.debugLine="Sub sub_ink_ml_menu_initial";
Debug.ShouldStop(4);
 BA.debugLineNum = 292;BA.debugLine="For i = 0 To (cnt_int_ink_ml_array_size-1)";
Debug.ShouldStop(8);
{
final int step1 = 1;
final int limit1 = (RemoteObject.solve(new RemoteObject[] {main._cnt_int_ink_ml_array_size,RemoteObject.createImmutable(1)}, "-",1, 1)).<Integer>get().intValue();
_i = 0 ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 293;BA.debugLine="ListView_ink_ml.AddsingleLine2(ary_str_ink_ml_na";
Debug.ShouldStop(16);
main.mostCurrent._listview_ink_ml.runVoidMethod ("AddSingleLine2",(Object)(BA.ObjectToCharSequence(main.mostCurrent._ary_str_ink_ml_name.getArrayElement(true,BA.numberCast(int.class, _i)))),(Object)((main._ary_int_ink_ml_value.getArrayElement(true,BA.numberCast(int.class, _i)))));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 295;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _sub_profit_menu_initial() throws Exception{
try {
		Debug.PushSubsStack("sub_profit_menu_initial (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,305);
if (RapidSub.canDelegate("sub_profit_menu_initial")) return b4a.example.main.remoteMe.runUserSub(false, "main","sub_profit_menu_initial");
int _i = 0;
 BA.debugLineNum = 305;BA.debugLine="Sub sub_profit_menu_initial";
Debug.ShouldStop(65536);
 BA.debugLineNum = 306;BA.debugLine="For i = 0 To (cnt_int_profit_array_size-1)";
Debug.ShouldStop(131072);
{
final int step1 = 1;
final int limit1 = (RemoteObject.solve(new RemoteObject[] {main._cnt_int_profit_array_size,RemoteObject.createImmutable(1)}, "-",1, 1)).<Integer>get().intValue();
_i = 0 ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 307;BA.debugLine="ListView_profit.AddTwoLines2(ary_str_profit_name";
Debug.ShouldStop(262144);
main.mostCurrent._listview_profit.runVoidMethod ("AddTwoLines2",(Object)(BA.ObjectToCharSequence(main.mostCurrent._ary_str_profit_name.getArrayElement(true,BA.numberCast(int.class, _i)))),(Object)(BA.ObjectToCharSequence(main.mostCurrent._ary_str_profit_unit.getArrayElement(true,BA.numberCast(int.class, _i)))),(Object)((main._ary_dbl_profit_value.getArrayElement(true,BA.numberCast(int.class, _i)))));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 309;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _sub_update_menu() throws Exception{
try {
		Debug.PushSubsStack("sub_update_menu (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,281);
if (RapidSub.canDelegate("sub_update_menu")) return b4a.example.main.remoteMe.runUserSub(false, "main","sub_update_menu");
 BA.debugLineNum = 281;BA.debugLine="Sub sub_update_menu";
Debug.ShouldStop(16777216);
 BA.debugLineNum = 282;BA.debugLine="Label_ink_ml.Text = ary_str_ink_ml_name(int_selec";
Debug.ShouldStop(33554432);
main.mostCurrent._label_ink_ml.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._ary_str_ink_ml_name.getArrayElement(true,main._int_select_ink_ml_index)));
 BA.debugLineNum = 283;BA.debugLine="Label_ink_name.Text = ary_str_ink_name(int_select";
Debug.ShouldStop(67108864);
main.mostCurrent._label_ink_name.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._ary_str_ink_name.getArrayElement(true,main._int_select_ink_index)));
 BA.debugLineNum = 284;BA.debugLine="Label_ink_price.Text = ary_str_ink_price(int_sele";
Debug.ShouldStop(134217728);
main.mostCurrent._label_ink_price.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._ary_str_ink_price.getArrayElement(true,main._int_select_ink_index)));
 BA.debugLineNum = 285;BA.debugLine="Label_profit_name.Text = ary_str_profit_name(int_";
Debug.ShouldStop(268435456);
main.mostCurrent._label_profit_name.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._ary_str_profit_name.getArrayElement(true,main._int_select_profit_index)));
 BA.debugLineNum = 286;BA.debugLine="Label_profit_unit.Text = ary_str_profit_unit(int_";
Debug.ShouldStop(536870912);
main.mostCurrent._label_profit_unit.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._ary_str_profit_unit.getArrayElement(true,main._int_select_profit_index)));
 BA.debugLineNum = 287;BA.debugLine="EditTextResult.Text = int_cal_result";
Debug.ShouldStop(1073741824);
main.mostCurrent._edittextresult.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(main._int_cal_result));
 BA.debugLineNum = 288;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}