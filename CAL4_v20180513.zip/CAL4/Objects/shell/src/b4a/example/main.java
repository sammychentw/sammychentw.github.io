
package b4a.example;

import java.io.IOException;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RDebug;
import anywheresoftware.b4a.pc.RemoteObject;
import anywheresoftware.b4a.pc.RDebug.IRemote;
import anywheresoftware.b4a.pc.Debug;
import anywheresoftware.b4a.pc.B4XTypes.B4XClass;
import anywheresoftware.b4a.pc.B4XTypes.DeviceClass;

public class main implements IRemote{
	public static main mostCurrent;
	public static RemoteObject processBA;
    public static boolean processGlobalsRun;
    public static RemoteObject myClass;
    public static RemoteObject remoteMe;
	public main() {
		mostCurrent = this;
	}
    public RemoteObject getRemoteMe() {
        return remoteMe;    
    }
    
	public static void main (String[] args) throws Exception {
		new RDebug(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]), args[3]);
		RDebug.INSTANCE.waitForTask();

	}
    static {
        anywheresoftware.b4a.pc.RapidSub.moduleToObject.put(new B4XClass("main"), "b4a.example.main");
	}

public boolean isSingleton() {
		return true;
	}
     public static RemoteObject getObject() {
		return myClass;
	 }

	public RemoteObject activityBA;
	public RemoteObject _activity;
    private PCBA pcBA;

	public PCBA create(Object[] args) throws ClassNotFoundException{
		processBA = (RemoteObject) args[1];
		activityBA = (RemoteObject) args[2];
		_activity = (RemoteObject) args[3];
        anywheresoftware.b4a.keywords.Common.Density = (Float)args[4];
        remoteMe = (RemoteObject) args[5];
		pcBA = new PCBA(this, main.class);
        main_subs_0.initializeProcessGlobals();
		return pcBA;
	}
public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _panelmainmenu = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _button_ink_ml = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button_ink_price = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button_profit = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button_clear = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button_single_calculation = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button_total_calculation = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button_bottle = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button_one_bottle = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _edittextresult = RemoteObject.declareNull("anywheresoftware.b4a.objects.EditTextWrapper");
public static RemoteObject _label_ink_ml = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label_ink_name = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label_ink_price = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label_profit_name = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label_profit_unit = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _panel_ink_ml = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _listview_ink_ml = RemoteObject.declareNull("anywheresoftware.b4a.objects.ListViewWrapper");
public static RemoteObject _panel_ink = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _listview_ink = RemoteObject.declareNull("anywheresoftware.b4a.objects.ListViewWrapper");
public static RemoteObject _panel_profit = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _listview_profit = RemoteObject.declareNull("anywheresoftware.b4a.objects.ListViewWrapper");
public static RemoteObject _cnt_default_ink_ml_index = RemoteObject.createImmutable(0);
public static RemoteObject _cnt_default_ink_name_index = RemoteObject.createImmutable(0);
public static RemoteObject _cnt_default_profit_name_index = RemoteObject.createImmutable(0);
public static RemoteObject _cnt_int_ink_ml_array_size = RemoteObject.createImmutable(0);
public static RemoteObject _cnt_int_ink_array_size = RemoteObject.createImmutable(0);
public static RemoteObject _cnt_int_profit_array_size = RemoteObject.createImmutable(0);
public static RemoteObject _ary_str_ink_ml_name = null;
public static RemoteObject _ary_int_ink_ml_value = null;
public static RemoteObject _ary_str_ink_name = null;
public static RemoteObject _ary_str_ink_price = null;
public static RemoteObject _ary_dbl_ink_value = null;
public static RemoteObject _ary_str_profit_name = null;
public static RemoteObject _ary_str_profit_unit = null;
public static RemoteObject _ary_dbl_profit_value = null;
public static RemoteObject _int_select_ink_ml_index = RemoteObject.createImmutable(0);
public static RemoteObject _int_select_ink_index = RemoteObject.createImmutable(0);
public static RemoteObject _int_select_profit_index = RemoteObject.createImmutable(0);
public static RemoteObject _int_bottle = RemoteObject.createImmutable(0);
public static RemoteObject _int_cal_result = RemoteObject.createImmutable(0);
public static b4a.example.starter _starter = null;
  public Object[] GetGlobals() {
		return new Object[] {"Activity",main.mostCurrent._activity,"ary_dbl_ink_value",main._ary_dbl_ink_value,"ary_dbl_profit_value",main._ary_dbl_profit_value,"ary_int_ink_ml_value",main._ary_int_ink_ml_value,"ary_str_ink_ml_name",main.mostCurrent._ary_str_ink_ml_name,"ary_str_ink_name",main.mostCurrent._ary_str_ink_name,"ary_str_ink_price",main.mostCurrent._ary_str_ink_price,"ary_str_profit_name",main.mostCurrent._ary_str_profit_name,"ary_str_profit_unit",main.mostCurrent._ary_str_profit_unit,"Button_bottle",main.mostCurrent._button_bottle,"Button_clear",main.mostCurrent._button_clear,"Button_ink_ml",main.mostCurrent._button_ink_ml,"Button_ink_price",main.mostCurrent._button_ink_price,"Button_one_bottle",main.mostCurrent._button_one_bottle,"Button_profit",main.mostCurrent._button_profit,"Button_single_calculation",main.mostCurrent._button_single_calculation,"Button_total_calculation",main.mostCurrent._button_total_calculation,"cnt_default_ink_ml_index",main._cnt_default_ink_ml_index,"cnt_default_ink_name_index",main._cnt_default_ink_name_index,"cnt_default_profit_name_index",main._cnt_default_profit_name_index,"cnt_int_ink_array_size",main._cnt_int_ink_array_size,"cnt_int_ink_ml_array_size",main._cnt_int_ink_ml_array_size,"cnt_int_profit_array_size",main._cnt_int_profit_array_size,"EditTextResult",main.mostCurrent._edittextresult,"int_bottle",main._int_bottle,"int_cal_result",main._int_cal_result,"int_select_ink_index",main._int_select_ink_index,"int_select_ink_ml_index",main._int_select_ink_ml_index,"int_select_profit_index",main._int_select_profit_index,"Label_ink_ml",main.mostCurrent._label_ink_ml,"Label_ink_name",main.mostCurrent._label_ink_name,"Label_ink_price",main.mostCurrent._label_ink_price,"Label_profit_name",main.mostCurrent._label_profit_name,"Label_profit_unit",main.mostCurrent._label_profit_unit,"ListView_ink",main.mostCurrent._listview_ink,"ListView_ink_ml",main.mostCurrent._listview_ink_ml,"ListView_profit",main.mostCurrent._listview_profit,"Panel_ink",main.mostCurrent._panel_ink,"Panel_ink_ml",main.mostCurrent._panel_ink_ml,"Panel_profit",main.mostCurrent._panel_profit,"PanelMainMenu",main.mostCurrent._panelmainmenu,"Starter",Debug.moduleToString(b4a.example.starter.class)};
}
}