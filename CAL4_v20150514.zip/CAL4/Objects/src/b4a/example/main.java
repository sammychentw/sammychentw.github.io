package b4a.example;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = true;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "b4a.example", "b4a.example.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "b4a.example", "b4a.example.main");
        anywheresoftware.b4a.keywords.Common.ToastMessageShow("This application was developed with B4A trial version and should not be distributed.", true);
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
			if (mostCurrent == null || mostCurrent != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
		    processBA.raiseEvent(mostCurrent._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.PanelWrapper _panelmainmenu = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_ink_ml = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_ink_price = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_profit = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_clear = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_single_calculation = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_total_calculation = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_bottle = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button_one_bottle = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittextresult = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_ink_ml = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_ink_name = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_ink_price = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_profit_name = null;
public anywheresoftware.b4a.objects.LabelWrapper _label_profit_unit = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel_ink_ml = null;
public anywheresoftware.b4a.objects.ListViewWrapper _listview_ink_ml = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel_ink = null;
public anywheresoftware.b4a.objects.ListViewWrapper _listview_ink = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel_profit = null;
public anywheresoftware.b4a.objects.ListViewWrapper _listview_profit = null;
public static int _cnt_default_ink_ml_index = 0;
public static int _cnt_default_ink_name_index = 0;
public static int _cnt_default_profit_name_index = 0;
public static int _cnt_int_ink_ml_array_size = 0;
public static int _cnt_int_ink_array_size = 0;
public static int _cnt_int_profit_array_size = 0;
public static String[] _ary_str_ink_ml_name = null;
public static int[] _ary_int_ink_ml_value = null;
public static String[] _ary_str_ink_name = null;
public static String[] _ary_str_ink_price = null;
public static double[] _ary_dbl_ink_value = null;
public static String[] _ary_str_profit_name = null;
public static String[] _ary_str_profit_unit = null;
public static double[] _ary_dbl_profit_value = null;
public static int _int_select_ink_ml_index = 0;
public static int _int_select_ink_index = 0;
public static int _int_select_profit_index = 0;
public static int _int_bottle = 0;
public static int _int_cal_result = 0;
public static boolean _bol_main_menu_mode = false;
public b4a.example.starter _starter = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static String  _activity_create(boolean _firsttime) throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 72;BA.debugLine="Activity.LoadLayout(\"1\")";
mostCurrent._activity.LoadLayout("1",mostCurrent.activityBA);
 //BA.debugLineNum = 73;BA.debugLine="Activity.Title = \"分裝價格計算機(墨水) V2018-05-14\"	'APP抬頭";
mostCurrent._activity.setTitle(BA.ObjectToCharSequence("分裝價格計算機(墨水) V2018-05-14"));
 //BA.debugLineNum = 75;BA.debugLine="ary_str_ink_ml_name(0) = \"5ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (0)] = "5ml";
 //BA.debugLineNum = 76;BA.debugLine="ary_str_ink_ml_name(1) = \"10ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (1)] = "10ml";
 //BA.debugLineNum = 77;BA.debugLine="ary_str_ink_ml_name(2) = \"3ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (2)] = "3ml";
 //BA.debugLineNum = 78;BA.debugLine="ary_str_ink_ml_name(3) = \"6ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (3)] = "6ml";
 //BA.debugLineNum = 79;BA.debugLine="ary_str_ink_ml_name(4) = \"8ml\"";
mostCurrent._ary_str_ink_ml_name[(int) (4)] = "8ml";
 //BA.debugLineNum = 81;BA.debugLine="ary_int_ink_ml_value(0) = 5";
_ary_int_ink_ml_value[(int) (0)] = (int) (5);
 //BA.debugLineNum = 82;BA.debugLine="ary_int_ink_ml_value(1) = 10";
_ary_int_ink_ml_value[(int) (1)] = (int) (10);
 //BA.debugLineNum = 83;BA.debugLine="ary_int_ink_ml_value(2) = 3";
_ary_int_ink_ml_value[(int) (2)] = (int) (3);
 //BA.debugLineNum = 84;BA.debugLine="ary_int_ink_ml_value(3) = 6";
_ary_int_ink_ml_value[(int) (3)] = (int) (6);
 //BA.debugLineNum = 85;BA.debugLine="ary_int_ink_ml_value(4) = 8";
_ary_int_ink_ml_value[(int) (4)] = (int) (8);
 //BA.debugLineNum = 87;BA.debugLine="ary_str_ink_name(0) = \"Pilot 百樂 Iroshizuku 色彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (0)] = "Pilot 百樂 Iroshizuku 色彩墨水";
 //BA.debugLineNum = 88;BA.debugLine="ary_str_ink_name(1) = \"日本 KOBE INK物語 限定墨水\"";
mostCurrent._ary_str_ink_name[(int) (1)] = "日本 KOBE INK物語 限定墨水";
 //BA.debugLineNum = 89;BA.debugLine="ary_str_ink_name(2) = \"DIAMINE SHIMMERTASTIC 金銀粉\"";
mostCurrent._ary_str_ink_name[(int) (2)] = "DIAMINE SHIMMERTASTIC 金銀粉";
 //BA.debugLineNum = 90;BA.debugLine="ary_str_ink_name(3) = \"英國 DIAMINE 墨水\"";
mostCurrent._ary_str_ink_name[(int) (3)] = "英國 DIAMINE 墨水";
 //BA.debugLineNum = 91;BA.debugLine="ary_str_ink_name(4) = \"英國 DIAMINE 150th 墨水\"";
mostCurrent._ary_str_ink_name[(int) (4)] = "英國 DIAMINE 150th 墨水";
 //BA.debugLineNum = 92;BA.debugLine="ary_str_ink_name(5) = \"英國 DIAMINE 花系列、音樂家墨水\"";
mostCurrent._ary_str_ink_name[(int) (5)] = "英國 DIAMINE 花系列、音樂家墨水";
 //BA.debugLineNum = 93;BA.debugLine="ary_str_ink_name(6) = \"中國 壇水墨水\"";
mostCurrent._ary_str_ink_name[(int) (6)] = "中國 壇水墨水";
 //BA.debugLineNum = 94;BA.debugLine="ary_str_ink_name(7) = \"中國 壇水金銀粉墨水\"";
mostCurrent._ary_str_ink_name[(int) (7)] = "中國 壇水金銀粉墨水";
 //BA.debugLineNum = 95;BA.debugLine="ary_str_ink_name(8) = \"臺灣 醃漬物 墨水\"";
mostCurrent._ary_str_ink_name[(int) (8)] = "臺灣 醃漬物 墨水";
 //BA.debugLineNum = 96;BA.debugLine="ary_str_ink_name(9) = \"臺灣 臺灣人物 墨水\"";
mostCurrent._ary_str_ink_name[(int) (9)] = "臺灣 臺灣人物 墨水";
 //BA.debugLineNum = 97;BA.debugLine="ary_str_ink_name(10) = \"CROSS 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (10)] = "CROSS 鋼筆墨水";
 //BA.debugLineNum = 98;BA.debugLine="ary_str_ink_name(11) = \"ROHRER & KLINGNER 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (11)] = "ROHRER & KLINGNER 鋼筆墨水";
 //BA.debugLineNum = 99;BA.debugLine="ary_str_ink_name(12) = \"ROHRER & KLINGNER 蟲膠金銀墨水\"";
mostCurrent._ary_str_ink_name[(int) (12)] = "ROHRER & KLINGNER 蟲膠金銀墨水";
 //BA.debugLineNum = 100;BA.debugLine="ary_str_ink_name(13) = \"ROHRER & KLINGNER 蟲膠墨水\"";
mostCurrent._ary_str_ink_name[(int) (13)] = "ROHRER & KLINGNER 蟲膠墨水";
 //BA.debugLineNum = 101;BA.debugLine="ary_str_ink_name(14) = \"ROHRER & KLINGNER 速寫墨水\"";
mostCurrent._ary_str_ink_name[(int) (14)] = "ROHRER & KLINGNER 速寫墨水";
 //BA.debugLineNum = 102;BA.debugLine="ary_str_ink_name(15) = \"ROHRER & KLINGNER 防水檔案墨水\"";
mostCurrent._ary_str_ink_name[(int) (15)] = "ROHRER & KLINGNER 防水檔案墨水";
 //BA.debugLineNum = 103;BA.debugLine="ary_str_ink_name(16) = \"ROHRER & KLINGNER 古典沾水筆墨水";
mostCurrent._ary_str_ink_name[(int) (16)] = "ROHRER & KLINGNER 古典沾水筆墨水";
 //BA.debugLineNum = 104;BA.debugLine="ary_str_ink_name(17) = \"丹麥 喬治傑森 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (17)] = "丹麥 喬治傑森 鋼筆墨水";
 //BA.debugLineNum = 105;BA.debugLine="ary_str_ink_name(18) = \"KWZ 標準鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (18)] = "KWZ 標準鋼筆墨水";
 //BA.debugLineNum = 106;BA.debugLine="ary_str_ink_name(19) = \"KWZ 防水鐵膽墨水\"";
mostCurrent._ary_str_ink_name[(int) (19)] = "KWZ 防水鐵膽墨水";
 //BA.debugLineNum = 107;BA.debugLine="ary_str_ink_name(20) = \"Faber-Castell 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (20)] = "Faber-Castell 鋼筆墨水";
 //BA.debugLineNum = 108;BA.debugLine="ary_str_ink_name(21) = \"德國 Jansen 手工墨水\"";
mostCurrent._ary_str_ink_name[(int) (21)] = "德國 Jansen 手工墨水";
 //BA.debugLineNum = 109;BA.debugLine="ary_str_ink_name(22) = \"德國 Jansen 手工香味墨水\"";
mostCurrent._ary_str_ink_name[(int) (22)] = "德國 Jansen 手工香味墨水";
 //BA.debugLineNum = 110;BA.debugLine="ary_str_ink_name(23) = \"德國 Jansen 香奈兒香味墨水\"";
mostCurrent._ary_str_ink_name[(int) (23)] = "德國 Jansen 香奈兒香味墨水";
 //BA.debugLineNum = 111;BA.debugLine="ary_str_ink_name(24) = \"百利金 4001 墨水\"";
mostCurrent._ary_str_ink_name[(int) (24)] = "百利金 4001 墨水";
 //BA.debugLineNum = 112;BA.debugLine="ary_str_ink_name(25) = \"百利金 4001 碳素墨水\"";
mostCurrent._ary_str_ink_name[(int) (25)] = "百利金 4001 碳素墨水";
 //BA.debugLineNum = 113;BA.debugLine="ary_str_ink_name(26) = \"百利金 Edelstein 逸彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (26)] = "百利金 Edelstein 逸彩墨水";
 //BA.debugLineNum = 114;BA.debugLine="ary_str_ink_name(27) = \"日本白金 Classic Ink 古典墨水\"";
mostCurrent._ary_str_ink_name[(int) (27)] = "日本白金 Classic Ink 古典墨水";
 //BA.debugLineNum = 115;BA.debugLine="ary_str_ink_name(28) = \"日本白金 Mixable ink 混色墨水\"";
mostCurrent._ary_str_ink_name[(int) (28)] = "日本白金 Mixable ink 混色墨水";
 //BA.debugLineNum = 116;BA.debugLine="ary_str_ink_name(29) = \"日本白金 Mixable ink 墨水調和液\"";
mostCurrent._ary_str_ink_name[(int) (29)] = "日本白金 Mixable ink 墨水調和液";
 //BA.debugLineNum = 117;BA.debugLine="ary_str_ink_name(30) = \"日本白金 超微粒子防水墨水\"";
mostCurrent._ary_str_ink_name[(int) (30)] = "日本白金 超微粒子防水墨水";
 //BA.debugLineNum = 118;BA.debugLine="ary_str_ink_name(31) = \"日本白金 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (31)] = "日本白金 鋼筆墨水";
 //BA.debugLineNum = 119;BA.debugLine="ary_str_ink_name(32) = \"寫樂 jentle ink 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (32)] = "寫樂 jentle ink 鋼筆墨水";
 //BA.debugLineNum = 120;BA.debugLine="ary_str_ink_name(33) = \"寫樂 STORiA 防水墨水\"";
mostCurrent._ary_str_ink_name[(int) (33)] = "寫樂 STORiA 防水墨水";
 //BA.debugLineNum = 121;BA.debugLine="ary_str_ink_name(34) = \"寫樂 （大）四季彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (34)] = "寫樂 （大）四季彩墨水";
 //BA.debugLineNum = 122;BA.debugLine="ary_str_ink_name(35) = \"寫樂 （新）四季彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (35)] = "寫樂 （新）四季彩墨水";
 //BA.debugLineNum = 123;BA.debugLine="ary_str_ink_name(36) = \"寫樂 （新）四季織墨水\"";
mostCurrent._ary_str_ink_name[(int) (36)] = "寫樂 （新）四季織墨水";
 //BA.debugLineNum = 124;BA.debugLine="ary_str_ink_name(37) = \"寫樂 防水墨水\"";
mostCurrent._ary_str_ink_name[(int) (37)] = "寫樂 防水墨水";
 //BA.debugLineNum = 125;BA.debugLine="ary_str_ink_name(38) = \"日本 京之音墨水\"";
mostCurrent._ary_str_ink_name[(int) (38)] = "日本 京之音墨水";
 //BA.debugLineNum = 126;BA.debugLine="ary_str_ink_name(39) = \"日本 京彩墨水\"";
mostCurrent._ary_str_ink_name[(int) (39)] = "日本 京彩墨水";
 //BA.debugLineNum = 127;BA.debugLine="ary_str_ink_name(40) = \"日本 京音京彩墨水限定色\"";
mostCurrent._ary_str_ink_name[(int) (40)] = "日本 京音京彩墨水限定色";
 //BA.debugLineNum = 128;BA.debugLine="ary_str_ink_name(41) = \"法國 J. Herbin 1670 墨水\"";
mostCurrent._ary_str_ink_name[(int) (41)] = "法國 J. Herbin 1670 墨水";
 //BA.debugLineNum = 129;BA.debugLine="ary_str_ink_name(42) = \"法國 J. Herbin 1798 墨水\"";
mostCurrent._ary_str_ink_name[(int) (42)] = "法國 J. Herbin 1798 墨水";
 //BA.debugLineNum = 130;BA.debugLine="ary_str_ink_name(43) = \"法國 J. Herbin 珍珠彩墨 墨水\"";
mostCurrent._ary_str_ink_name[(int) (43)] = "法國 J. Herbin 珍珠彩墨 墨水";
 //BA.debugLineNum = 131;BA.debugLine="ary_str_ink_name(44) = \"法國 都彭 S.T. DUPONT 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (44)] = "法國 都彭 S.T. DUPONT 鋼筆墨水";
 //BA.debugLineNum = 132;BA.debugLine="ary_str_ink_name(45) = \"瑞士 卡達 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (45)] = "瑞士 卡達 鋼筆墨水";
 //BA.debugLineNum = 133;BA.debugLine="ary_str_ink_name(46) = \"美國 Monteverde USA 核心墨水\"";
mostCurrent._ary_str_ink_name[(int) (46)] = "美國 Monteverde USA 核心墨水";
 //BA.debugLineNum = 134;BA.debugLine="ary_str_ink_name(47) = \"美國 Monteverde 鋼筆清洗劑\"";
mostCurrent._ary_str_ink_name[(int) (47)] = "美國 Monteverde 鋼筆清洗劑";
 //BA.debugLineNum = 135;BA.debugLine="ary_str_ink_name(48) = \"義大利 Aurora 鋼筆墨水\"";
mostCurrent._ary_str_ink_name[(int) (48)] = "義大利 Aurora 鋼筆墨水";
 //BA.debugLineNum = 136;BA.debugLine="ary_str_ink_name(49) = \"臺灣 墨堤 墨水\"";
mostCurrent._ary_str_ink_name[(int) (49)] = "臺灣 墨堤 墨水";
 //BA.debugLineNum = 137;BA.debugLine="ary_str_ink_name(50) = \"臺灣 道具屋藍濃 墨水\"";
mostCurrent._ary_str_ink_name[(int) (50)] = "臺灣 道具屋藍濃 墨水";
 //BA.debugLineNum = 138;BA.debugLine="ary_str_ink_name(51) = \"臺灣 道具屋藍濃 限定色墨水\"";
mostCurrent._ary_str_ink_name[(int) (51)] = "臺灣 道具屋藍濃 限定色墨水";
 //BA.debugLineNum = 139;BA.debugLine="ary_str_ink_name(52) = \"臺灣 道具屋藍濃 防水墨水\"";
mostCurrent._ary_str_ink_name[(int) (52)] = "臺灣 道具屋藍濃 防水墨水";
 //BA.debugLineNum = 140;BA.debugLine="ary_str_ink_name(53) = \"英國 YARD-O-LED 墨水\"";
mostCurrent._ary_str_ink_name[(int) (53)] = "英國 YARD-O-LED 墨水";
 //BA.debugLineNum = 141;BA.debugLine="ary_str_ink_name(54) = \"西華 鋼筆 墨水\"";
mostCurrent._ary_str_ink_name[(int) (54)] = "西華 鋼筆 墨水";
 //BA.debugLineNum = 143;BA.debugLine="ary_str_ink_price(0) = \"50ML 480元\"";
mostCurrent._ary_str_ink_price[(int) (0)] = "50ML 480元";
 //BA.debugLineNum = 144;BA.debugLine="ary_str_ink_price(1) = \"50ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (1)] = "50ML 550元";
 //BA.debugLineNum = 145;BA.debugLine="ary_str_ink_price(2) = \"50ML 440元\"";
mostCurrent._ary_str_ink_price[(int) (2)] = "50ML 440元";
 //BA.debugLineNum = 146;BA.debugLine="ary_str_ink_price(3) = \"80ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (3)] = "80ML 300元";
 //BA.debugLineNum = 147;BA.debugLine="ary_str_ink_price(4) = \"40ML 325元\"";
mostCurrent._ary_str_ink_price[(int) (4)] = "40ML 325元";
 //BA.debugLineNum = 148;BA.debugLine="ary_str_ink_price(5) = \"30ML 270元\"";
mostCurrent._ary_str_ink_price[(int) (5)] = "30ML 270元";
 //BA.debugLineNum = 149;BA.debugLine="ary_str_ink_price(6) = \"60ML 200元\"";
mostCurrent._ary_str_ink_price[(int) (6)] = "60ML 200元";
 //BA.debugLineNum = 150;BA.debugLine="ary_str_ink_price(7) = \"60ML 220元\"";
mostCurrent._ary_str_ink_price[(int) (7)] = "60ML 220元";
 //BA.debugLineNum = 151;BA.debugLine="ary_str_ink_price(8) = \"15ML 220元\"";
mostCurrent._ary_str_ink_price[(int) (8)] = "15ML 220元";
 //BA.debugLineNum = 152;BA.debugLine="ary_str_ink_price(9) = \"30ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (9)] = "30ML 300元";
 //BA.debugLineNum = 153;BA.debugLine="ary_str_ink_price(10) = \"62.5ML 350元\"";
mostCurrent._ary_str_ink_price[(int) (10)] = "62.5ML 350元";
 //BA.debugLineNum = 154;BA.debugLine="ary_str_ink_price(11) = \"50ML 350元\"";
mostCurrent._ary_str_ink_price[(int) (11)] = "50ML 350元";
 //BA.debugLineNum = 155;BA.debugLine="ary_str_ink_price(12) = \"50ML 350元\"";
mostCurrent._ary_str_ink_price[(int) (12)] = "50ML 350元";
 //BA.debugLineNum = 156;BA.debugLine="ary_str_ink_price(13) = \"50ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (13)] = "50ML 300元";
 //BA.debugLineNum = 157;BA.debugLine="ary_str_ink_price(14) = \"50ML 450元\"";
mostCurrent._ary_str_ink_price[(int) (14)] = "50ML 450元";
 //BA.debugLineNum = 158;BA.debugLine="ary_str_ink_price(15) = \"50ML 700元\"";
mostCurrent._ary_str_ink_price[(int) (15)] = "50ML 700元";
 //BA.debugLineNum = 159;BA.debugLine="ary_str_ink_price(16) = \"100ML 400元\"";
mostCurrent._ary_str_ink_price[(int) (16)] = "100ML 400元";
 //BA.debugLineNum = 160;BA.debugLine="ary_str_ink_price(17) = \"35ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (17)] = "35ML 550元";
 //BA.debugLineNum = 161;BA.debugLine="ary_str_ink_price(18) = \"60ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (18)] = "60ML 550元";
 //BA.debugLineNum = 162;BA.debugLine="ary_str_ink_price(19) = \"60ML 600元\"";
mostCurrent._ary_str_ink_price[(int) (19)] = "60ML 600元";
 //BA.debugLineNum = 163;BA.debugLine="ary_str_ink_price(20) = \"75ML 960元\"";
mostCurrent._ary_str_ink_price[(int) (20)] = "75ML 960元";
 //BA.debugLineNum = 164;BA.debugLine="ary_str_ink_price(21) = \"35ML 450元\"";
mostCurrent._ary_str_ink_price[(int) (21)] = "35ML 450元";
 //BA.debugLineNum = 165;BA.debugLine="ary_str_ink_price(22) = \"35ML 500元\"";
mostCurrent._ary_str_ink_price[(int) (22)] = "35ML 500元";
 //BA.debugLineNum = 166;BA.debugLine="ary_str_ink_price(23) = \"35ML 650元\"";
mostCurrent._ary_str_ink_price[(int) (23)] = "35ML 650元";
 //BA.debugLineNum = 167;BA.debugLine="ary_str_ink_price(24) = \"62.5ML 240元\"";
mostCurrent._ary_str_ink_price[(int) (24)] = "62.5ML 240元";
 //BA.debugLineNum = 168;BA.debugLine="ary_str_ink_price(25) = \"30ML 240元\"";
mostCurrent._ary_str_ink_price[(int) (25)] = "30ML 240元";
 //BA.debugLineNum = 169;BA.debugLine="ary_str_ink_price(26) = \"50ML 490元\"";
mostCurrent._ary_str_ink_price[(int) (26)] = "50ML 490元";
 //BA.debugLineNum = 170;BA.debugLine="ary_str_ink_price(27) = \"60ML 630元\"";
mostCurrent._ary_str_ink_price[(int) (27)] = "60ML 630元";
 //BA.debugLineNum = 171;BA.debugLine="ary_str_ink_price(28) = \"60ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (28)] = "60ML 300元";
 //BA.debugLineNum = 172;BA.debugLine="ary_str_ink_price(29) = \"50ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (29)] = "50ML 300元";
 //BA.debugLineNum = 173;BA.debugLine="ary_str_ink_price(30) = \"60ML 400元\"";
mostCurrent._ary_str_ink_price[(int) (30)] = "60ML 400元";
 //BA.debugLineNum = 174;BA.debugLine="ary_str_ink_price(31) = \"60ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (31)] = "60ML 300元";
 //BA.debugLineNum = 175;BA.debugLine="ary_str_ink_price(32) = \"50ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (32)] = "50ML 300元";
 //BA.debugLineNum = 176;BA.debugLine="ary_str_ink_price(33) = \"30ML 450元\"";
mostCurrent._ary_str_ink_price[(int) (33)] = "30ML 450元";
 //BA.debugLineNum = 177;BA.debugLine="ary_str_ink_price(34) = \"50ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (34)] = "50ML 300元";
 //BA.debugLineNum = 178;BA.debugLine="ary_str_ink_price(35) = \"20ML 250元\"";
mostCurrent._ary_str_ink_price[(int) (35)] = "20ML 250元";
 //BA.debugLineNum = 179;BA.debugLine="ary_str_ink_price(36) = \"20ML 280元\"";
mostCurrent._ary_str_ink_price[(int) (36)] = "20ML 280元";
 //BA.debugLineNum = 180;BA.debugLine="ary_str_ink_price(37) = \"50ML 500元\"";
mostCurrent._ary_str_ink_price[(int) (37)] = "50ML 500元";
 //BA.debugLineNum = 181;BA.debugLine="ary_str_ink_price(38) = \"40ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (38)] = "40ML 550元";
 //BA.debugLineNum = 182;BA.debugLine="ary_str_ink_price(39) = \"40ML 550元\"";
mostCurrent._ary_str_ink_price[(int) (39)] = "40ML 550元";
 //BA.debugLineNum = 183;BA.debugLine="ary_str_ink_price(40) = \"40ML 650元\"";
mostCurrent._ary_str_ink_price[(int) (40)] = "40ML 650元";
 //BA.debugLineNum = 184;BA.debugLine="ary_str_ink_price(41) = \"50ML 650元\"";
mostCurrent._ary_str_ink_price[(int) (41)] = "50ML 650元";
 //BA.debugLineNum = 185;BA.debugLine="ary_str_ink_price(42) = \"50ML 800元\"";
mostCurrent._ary_str_ink_price[(int) (42)] = "50ML 800元";
 //BA.debugLineNum = 186;BA.debugLine="ary_str_ink_price(43) = \"30ML 300元\"";
mostCurrent._ary_str_ink_price[(int) (43)] = "30ML 300元";
 //BA.debugLineNum = 187;BA.debugLine="ary_str_ink_price(44) = \"50ML 600元\"";
mostCurrent._ary_str_ink_price[(int) (44)] = "50ML 600元";
 //BA.debugLineNum = 188;BA.debugLine="ary_str_ink_price(45) = \"50ML 945元\"";
mostCurrent._ary_str_ink_price[(int) (45)] = "50ML 945元";
 //BA.debugLineNum = 189;BA.debugLine="ary_str_ink_price(46) = \"90ML 368元\"";
mostCurrent._ary_str_ink_price[(int) (46)] = "90ML 368元";
 //BA.debugLineNum = 190;BA.debugLine="ary_str_ink_price(47) = \"480ML 576元\"";
mostCurrent._ary_str_ink_price[(int) (47)] = "480ML 576元";
 //BA.debugLineNum = 191;BA.debugLine="ary_str_ink_price(48) = \"45ML 360元\"";
mostCurrent._ary_str_ink_price[(int) (48)] = "45ML 360元";
 //BA.debugLineNum = 192;BA.debugLine="ary_str_ink_price(49) = \"20ML 220元\"";
mostCurrent._ary_str_ink_price[(int) (49)] = "20ML 220元";
 //BA.debugLineNum = 193;BA.debugLine="ary_str_ink_price(50) = \"30ML 200元\"";
mostCurrent._ary_str_ink_price[(int) (50)] = "30ML 200元";
 //BA.debugLineNum = 194;BA.debugLine="ary_str_ink_price(51) = \"30ML 250元\"";
mostCurrent._ary_str_ink_price[(int) (51)] = "30ML 250元";
 //BA.debugLineNum = 195;BA.debugLine="ary_str_ink_price(52) = \"30ML 230元\"";
mostCurrent._ary_str_ink_price[(int) (52)] = "30ML 230元";
 //BA.debugLineNum = 196;BA.debugLine="ary_str_ink_price(53) = \"28.4ML 280元\"";
mostCurrent._ary_str_ink_price[(int) (53)] = "28.4ML 280元";
 //BA.debugLineNum = 197;BA.debugLine="ary_str_ink_price(54) = \"50ML 190元\"";
mostCurrent._ary_str_ink_price[(int) (54)] = "50ML 190元";
 //BA.debugLineNum = 199;BA.debugLine="ary_dbl_ink_value(0) = 9.6";
_ary_dbl_ink_value[(int) (0)] = 9.6;
 //BA.debugLineNum = 200;BA.debugLine="ary_dbl_ink_value(1) = 11";
_ary_dbl_ink_value[(int) (1)] = 11;
 //BA.debugLineNum = 201;BA.debugLine="ary_dbl_ink_value(2) = 8.8";
_ary_dbl_ink_value[(int) (2)] = 8.8;
 //BA.debugLineNum = 202;BA.debugLine="ary_dbl_ink_value(3) = 3.75";
_ary_dbl_ink_value[(int) (3)] = 3.75;
 //BA.debugLineNum = 203;BA.debugLine="ary_dbl_ink_value(4) = 8.125";
_ary_dbl_ink_value[(int) (4)] = 8.125;
 //BA.debugLineNum = 204;BA.debugLine="ary_dbl_ink_value(5) = 9";
_ary_dbl_ink_value[(int) (5)] = 9;
 //BA.debugLineNum = 205;BA.debugLine="ary_dbl_ink_value(6) = 3.33";
_ary_dbl_ink_value[(int) (6)] = 3.33;
 //BA.debugLineNum = 206;BA.debugLine="ary_dbl_ink_value(7) = 3.66";
_ary_dbl_ink_value[(int) (7)] = 3.66;
 //BA.debugLineNum = 207;BA.debugLine="ary_dbl_ink_value(8) = 14.66";
_ary_dbl_ink_value[(int) (8)] = 14.66;
 //BA.debugLineNum = 208;BA.debugLine="ary_dbl_ink_value(9) = 10";
_ary_dbl_ink_value[(int) (9)] = 10;
 //BA.debugLineNum = 209;BA.debugLine="ary_dbl_ink_value(10) = 5.6";
_ary_dbl_ink_value[(int) (10)] = 5.6;
 //BA.debugLineNum = 210;BA.debugLine="ary_dbl_ink_value(11) = 7";
_ary_dbl_ink_value[(int) (11)] = 7;
 //BA.debugLineNum = 211;BA.debugLine="ary_dbl_ink_value(12) = 7";
_ary_dbl_ink_value[(int) (12)] = 7;
 //BA.debugLineNum = 212;BA.debugLine="ary_dbl_ink_value(13) = 6";
_ary_dbl_ink_value[(int) (13)] = 6;
 //BA.debugLineNum = 213;BA.debugLine="ary_dbl_ink_value(14) = 9";
_ary_dbl_ink_value[(int) (14)] = 9;
 //BA.debugLineNum = 214;BA.debugLine="ary_dbl_ink_value(15) = 9";
_ary_dbl_ink_value[(int) (15)] = 9;
 //BA.debugLineNum = 215;BA.debugLine="ary_dbl_ink_value(16) = 4";
_ary_dbl_ink_value[(int) (16)] = 4;
 //BA.debugLineNum = 216;BA.debugLine="ary_dbl_ink_value(17) = 15.71";
_ary_dbl_ink_value[(int) (17)] = 15.71;
 //BA.debugLineNum = 217;BA.debugLine="ary_dbl_ink_value(18) = 9.16";
_ary_dbl_ink_value[(int) (18)] = 9.16;
 //BA.debugLineNum = 218;BA.debugLine="ary_dbl_ink_value(19) = 10";
_ary_dbl_ink_value[(int) (19)] = 10;
 //BA.debugLineNum = 219;BA.debugLine="ary_dbl_ink_value(20) = 12.8";
_ary_dbl_ink_value[(int) (20)] = 12.8;
 //BA.debugLineNum = 220;BA.debugLine="ary_dbl_ink_value(21) = 12.86";
_ary_dbl_ink_value[(int) (21)] = 12.86;
 //BA.debugLineNum = 221;BA.debugLine="ary_dbl_ink_value(22) = 14.29";
_ary_dbl_ink_value[(int) (22)] = 14.29;
 //BA.debugLineNum = 222;BA.debugLine="ary_dbl_ink_value(23) = 18.57";
_ary_dbl_ink_value[(int) (23)] = 18.57;
 //BA.debugLineNum = 223;BA.debugLine="ary_dbl_ink_value(24) = 3.84";
_ary_dbl_ink_value[(int) (24)] = 3.84;
 //BA.debugLineNum = 224;BA.debugLine="ary_dbl_ink_value(25) = 8";
_ary_dbl_ink_value[(int) (25)] = 8;
 //BA.debugLineNum = 225;BA.debugLine="ary_dbl_ink_value(26) = 9.8";
_ary_dbl_ink_value[(int) (26)] = 9.8;
 //BA.debugLineNum = 226;BA.debugLine="ary_dbl_ink_value(27) = 10.5";
_ary_dbl_ink_value[(int) (27)] = 10.5;
 //BA.debugLineNum = 227;BA.debugLine="ary_dbl_ink_value(28) = 5";
_ary_dbl_ink_value[(int) (28)] = 5;
 //BA.debugLineNum = 228;BA.debugLine="ary_dbl_ink_value(29) = 6";
_ary_dbl_ink_value[(int) (29)] = 6;
 //BA.debugLineNum = 229;BA.debugLine="ary_dbl_ink_value(30) = 6.66";
_ary_dbl_ink_value[(int) (30)] = 6.66;
 //BA.debugLineNum = 230;BA.debugLine="ary_dbl_ink_value(31) = 5";
_ary_dbl_ink_value[(int) (31)] = 5;
 //BA.debugLineNum = 231;BA.debugLine="ary_dbl_ink_value(32) = 6";
_ary_dbl_ink_value[(int) (32)] = 6;
 //BA.debugLineNum = 232;BA.debugLine="ary_dbl_ink_value(33) = 15";
_ary_dbl_ink_value[(int) (33)] = 15;
 //BA.debugLineNum = 233;BA.debugLine="ary_dbl_ink_value(34) = 6";
_ary_dbl_ink_value[(int) (34)] = 6;
 //BA.debugLineNum = 234;BA.debugLine="ary_dbl_ink_value(35) = 12.5";
_ary_dbl_ink_value[(int) (35)] = 12.5;
 //BA.debugLineNum = 235;BA.debugLine="ary_dbl_ink_value(36) = 14";
_ary_dbl_ink_value[(int) (36)] = 14;
 //BA.debugLineNum = 236;BA.debugLine="ary_dbl_ink_value(37) = 10";
_ary_dbl_ink_value[(int) (37)] = 10;
 //BA.debugLineNum = 237;BA.debugLine="ary_dbl_ink_value(38) = 13.75";
_ary_dbl_ink_value[(int) (38)] = 13.75;
 //BA.debugLineNum = 238;BA.debugLine="ary_dbl_ink_value(39) = 13.75";
_ary_dbl_ink_value[(int) (39)] = 13.75;
 //BA.debugLineNum = 239;BA.debugLine="ary_dbl_ink_value(40) = 16.25";
_ary_dbl_ink_value[(int) (40)] = 16.25;
 //BA.debugLineNum = 240;BA.debugLine="ary_dbl_ink_value(41) = 13";
_ary_dbl_ink_value[(int) (41)] = 13;
 //BA.debugLineNum = 241;BA.debugLine="ary_dbl_ink_value(42) = 16";
_ary_dbl_ink_value[(int) (42)] = 16;
 //BA.debugLineNum = 242;BA.debugLine="ary_dbl_ink_value(43) = 10";
_ary_dbl_ink_value[(int) (43)] = 10;
 //BA.debugLineNum = 243;BA.debugLine="ary_dbl_ink_value(44) = 12";
_ary_dbl_ink_value[(int) (44)] = 12;
 //BA.debugLineNum = 244;BA.debugLine="ary_dbl_ink_value(45) = 18.9";
_ary_dbl_ink_value[(int) (45)] = 18.9;
 //BA.debugLineNum = 245;BA.debugLine="ary_dbl_ink_value(46) = 4";
_ary_dbl_ink_value[(int) (46)] = 4;
 //BA.debugLineNum = 246;BA.debugLine="ary_dbl_ink_value(47) = 1.2";
_ary_dbl_ink_value[(int) (47)] = 1.2;
 //BA.debugLineNum = 247;BA.debugLine="ary_dbl_ink_value(48) = 8";
_ary_dbl_ink_value[(int) (48)] = 8;
 //BA.debugLineNum = 248;BA.debugLine="ary_dbl_ink_value(49) = 11";
_ary_dbl_ink_value[(int) (49)] = 11;
 //BA.debugLineNum = 249;BA.debugLine="ary_dbl_ink_value(50) = 6.66";
_ary_dbl_ink_value[(int) (50)] = 6.66;
 //BA.debugLineNum = 250;BA.debugLine="ary_dbl_ink_value(51) = 8.33";
_ary_dbl_ink_value[(int) (51)] = 8.33;
 //BA.debugLineNum = 251;BA.debugLine="ary_dbl_ink_value(52) = 7.66";
_ary_dbl_ink_value[(int) (52)] = 7.66;
 //BA.debugLineNum = 252;BA.debugLine="ary_dbl_ink_value(53) = 9.86";
_ary_dbl_ink_value[(int) (53)] = 9.86;
 //BA.debugLineNum = 253;BA.debugLine="ary_dbl_ink_value(54) = 3.8";
_ary_dbl_ink_value[(int) (54)] = 3.8;
 //BA.debugLineNum = 255;BA.debugLine="ary_str_profit_name(0) = \"10%\"";
mostCurrent._ary_str_profit_name[(int) (0)] = "10%";
 //BA.debugLineNum = 256;BA.debugLine="ary_str_profit_name(1) = \"20%\"";
mostCurrent._ary_str_profit_name[(int) (1)] = "20%";
 //BA.debugLineNum = 257;BA.debugLine="ary_str_profit_name(2) = \"25%\"";
mostCurrent._ary_str_profit_name[(int) (2)] = "25%";
 //BA.debugLineNum = 258;BA.debugLine="ary_str_profit_name(3) = \"30%\"";
mostCurrent._ary_str_profit_name[(int) (3)] = "30%";
 //BA.debugLineNum = 260;BA.debugLine="ary_str_profit_unit(0) = \"玻璃瓶10元\"";
mostCurrent._ary_str_profit_unit[(int) (0)] = "玻璃瓶10元";
 //BA.debugLineNum = 261;BA.debugLine="ary_str_profit_unit(1) = \"玻璃瓶10元\"";
mostCurrent._ary_str_profit_unit[(int) (1)] = "玻璃瓶10元";
 //BA.debugLineNum = 262;BA.debugLine="ary_str_profit_unit(2) = \"玻璃瓶10元\"";
mostCurrent._ary_str_profit_unit[(int) (2)] = "玻璃瓶10元";
 //BA.debugLineNum = 263;BA.debugLine="ary_str_profit_unit(3) = \"玻璃瓶10元\"";
mostCurrent._ary_str_profit_unit[(int) (3)] = "玻璃瓶10元";
 //BA.debugLineNum = 265;BA.debugLine="ary_dbl_profit_value(0) = 1.1";
_ary_dbl_profit_value[(int) (0)] = 1.1;
 //BA.debugLineNum = 266;BA.debugLine="ary_dbl_profit_value(1) = 1.2";
_ary_dbl_profit_value[(int) (1)] = 1.2;
 //BA.debugLineNum = 267;BA.debugLine="ary_dbl_profit_value(2) = 1.25";
_ary_dbl_profit_value[(int) (2)] = 1.25;
 //BA.debugLineNum = 268;BA.debugLine="ary_dbl_profit_value(3) = 1.3";
_ary_dbl_profit_value[(int) (3)] = 1.3;
 //BA.debugLineNum = 271;BA.debugLine="Button_clear_Click";
_button_clear_click();
 //BA.debugLineNum = 272;BA.debugLine="sub_ink_ml_menu_initial";
_sub_ink_ml_menu_initial();
 //BA.debugLineNum = 273;BA.debugLine="sub_ink_menu_initial";
_sub_ink_menu_initial();
 //BA.debugLineNum = 274;BA.debugLine="sub_profit_menu_initial";
_sub_profit_menu_initial();
 //BA.debugLineNum = 276;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 277;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 278;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 279;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 280;BA.debugLine="bol_main_menu_mode = True";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 281;BA.debugLine="End Sub";
return "";
}
public static boolean  _activity_keypress(int _keycode) throws Exception{
 //BA.debugLineNum = 418;BA.debugLine="Sub Activity_KeyPress (KeyCode As Int) As Boolean";
 //BA.debugLineNum = 419;BA.debugLine="If bol_main_menu_mode=True Then";
if (_bol_main_menu_mode==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 421;BA.debugLine="If KeyCode=4 Then";
if (_keycode==4) { 
 //BA.debugLineNum = 423;BA.debugLine="ExitApplication";
anywheresoftware.b4a.keywords.Common.ExitApplication();
 //BA.debugLineNum = 424;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 }else {
 //BA.debugLineNum = 428;BA.debugLine="If KeyCode=4 Then";
if (_keycode==4) { 
 //BA.debugLineNum = 430;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 431;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 432;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 433;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 434;BA.debugLine="bol_main_menu_mode=True";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 435;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 };
 };
 //BA.debugLineNum = 438;BA.debugLine="End Sub";
return false;
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 318;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 320;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 314;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 316;BA.debugLine="End Sub";
return "";
}
public static String  _button_bottle_click() throws Exception{
 //BA.debugLineNum = 365;BA.debugLine="Sub Button_bottle_Click";
 //BA.debugLineNum = 367;BA.debugLine="If int_cal_result>0 And int_bottle>=1 Then";
if (_int_cal_result>0 && _int_bottle>=1) { 
 //BA.debugLineNum = 368;BA.debugLine="int_cal_result=Round(int_cal_result-(int_bottle*";
_int_cal_result = (int) (anywheresoftware.b4a.keywords.Common.Round(_int_cal_result-(_int_bottle*10)));
 }else {
 //BA.debugLineNum = 370;BA.debugLine="Msgbox(\"無法折讓空瓶\",\"警告\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("無法折讓空瓶"),BA.ObjectToCharSequence("警告"),mostCurrent.activityBA);
 };
 //BA.debugLineNum = 372;BA.debugLine="sub_update_menu";
_sub_update_menu();
 //BA.debugLineNum = 373;BA.debugLine="End Sub";
return "";
}
public static String  _button_clear_click() throws Exception{
 //BA.debugLineNum = 341;BA.debugLine="Sub Button_clear_Click";
 //BA.debugLineNum = 343;BA.debugLine="int_select_ink_ml_index=cnt_default_ink_ml_index";
_int_select_ink_ml_index = _cnt_default_ink_ml_index;
 //BA.debugLineNum = 344;BA.debugLine="int_select_ink_index=cnt_default_ink_name_index";
_int_select_ink_index = _cnt_default_ink_name_index;
 //BA.debugLineNum = 345;BA.debugLine="int_select_profit_index=cnt_default_profit_name_i";
_int_select_profit_index = _cnt_default_profit_name_index;
 //BA.debugLineNum = 346;BA.debugLine="int_cal_result=0";
_int_cal_result = (int) (0);
 //BA.debugLineNum = 347;BA.debugLine="int_bottle=0";
_int_bottle = (int) (0);
 //BA.debugLineNum = 348;BA.debugLine="sub_update_menu";
_sub_update_menu();
 //BA.debugLineNum = 349;BA.debugLine="End Sub";
return "";
}
public static String  _button_ink_ml_click() throws Exception{
 //BA.debugLineNum = 323;BA.debugLine="Sub Button_ink_ml_Click";
 //BA.debugLineNum = 325;BA.debugLine="Panel_ink_ml.Visible = True";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 326;BA.debugLine="bol_main_menu_mode = False";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 327;BA.debugLine="End Sub";
return "";
}
public static String  _button_ink_price_click() throws Exception{
 //BA.debugLineNum = 329;BA.debugLine="Sub Button_ink_price_Click";
 //BA.debugLineNum = 331;BA.debugLine="Panel_ink.Visible = True";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 332;BA.debugLine="bol_main_menu_mode = False";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 333;BA.debugLine="End Sub";
return "";
}
public static String  _button_one_bottle_click() throws Exception{
 //BA.debugLineNum = 375;BA.debugLine="Sub Button_one_bottle_Click";
 //BA.debugLineNum = 377;BA.debugLine="If int_cal_result>0 Then";
if (_int_cal_result>0) { 
 //BA.debugLineNum = 378;BA.debugLine="int_cal_result=int_cal_result-10";
_int_cal_result = (int) (_int_cal_result-10);
 }else {
 //BA.debugLineNum = 380;BA.debugLine="Msgbox(\"沒有餘額，無法折讓空瓶\",\"警告\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("沒有餘額，無法折讓空瓶"),BA.ObjectToCharSequence("警告"),mostCurrent.activityBA);
 };
 //BA.debugLineNum = 382;BA.debugLine="sub_update_menu";
_sub_update_menu();
 //BA.debugLineNum = 383;BA.debugLine="End Sub";
return "";
}
public static String  _button_profit_click() throws Exception{
 //BA.debugLineNum = 335;BA.debugLine="Sub Button_profit_Click";
 //BA.debugLineNum = 337;BA.debugLine="Panel_profit.Visible = True";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 338;BA.debugLine="bol_main_menu_mode = False";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 339;BA.debugLine="End Sub";
return "";
}
public static String  _button_single_calculation_click() throws Exception{
 //BA.debugLineNum = 351;BA.debugLine="Sub Button_single_calculation_Click";
 //BA.debugLineNum = 353;BA.debugLine="int_bottle=1";
_int_bottle = (int) (1);
 //BA.debugLineNum = 354;BA.debugLine="int_cal_result=Round((ary_int_ink_ml_value(int_se";
_int_cal_result = (int) (anywheresoftware.b4a.keywords.Common.Round((_ary_int_ink_ml_value[_int_select_ink_ml_index]*_ary_dbl_ink_value[_int_select_ink_index]*_ary_dbl_profit_value[_int_select_profit_index]+10)));
 //BA.debugLineNum = 355;BA.debugLine="sub_update_menu";
_sub_update_menu();
 //BA.debugLineNum = 356;BA.debugLine="End Sub";
return "";
}
public static String  _button_total_calculation_click() throws Exception{
 //BA.debugLineNum = 358;BA.debugLine="Sub Button_total_calculation_Click";
 //BA.debugLineNum = 360;BA.debugLine="int_cal_result=int_cal_result+Round((ary_int_ink_";
_int_cal_result = (int) (_int_cal_result+anywheresoftware.b4a.keywords.Common.Round((_ary_int_ink_ml_value[_int_select_ink_ml_index]*_ary_dbl_ink_value[_int_select_ink_index]*_ary_dbl_profit_value[_int_select_profit_index]+10)));
 //BA.debugLineNum = 361;BA.debugLine="int_bottle=int_bottle+1";
_int_bottle = (int) (_int_bottle+1);
 //BA.debugLineNum = 362;BA.debugLine="sub_update_menu";
_sub_update_menu();
 //BA.debugLineNum = 363;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 25;BA.debugLine="Private PanelMainMenu As Panel";
mostCurrent._panelmainmenu = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private Button_ink_ml As Button";
mostCurrent._button_ink_ml = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private Button_ink_price As Button";
mostCurrent._button_ink_price = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private Button_profit As Button";
mostCurrent._button_profit = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private Button_clear As Button";
mostCurrent._button_clear = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private Button_single_calculation As Button";
mostCurrent._button_single_calculation = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private Button_total_calculation As Button";
mostCurrent._button_total_calculation = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private Button_bottle As Button";
mostCurrent._button_bottle = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private Button_one_bottle As Button";
mostCurrent._button_one_bottle = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private EditTextResult As EditText";
mostCurrent._edittextresult = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private Label_ink_ml As Label";
mostCurrent._label_ink_ml = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private Label_ink_name As Label";
mostCurrent._label_ink_name = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Private Label_ink_price As Label";
mostCurrent._label_ink_price = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 38;BA.debugLine="Private Label_profit_name As Label";
mostCurrent._label_profit_name = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Private Label_profit_unit As Label";
mostCurrent._label_profit_unit = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private Panel_ink_ml As Panel";
mostCurrent._panel_ink_ml = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 41;BA.debugLine="Private ListView_ink_ml As ListView";
mostCurrent._listview_ink_ml = new anywheresoftware.b4a.objects.ListViewWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private Panel_ink As Panel";
mostCurrent._panel_ink = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private ListView_ink As ListView";
mostCurrent._listview_ink = new anywheresoftware.b4a.objects.ListViewWrapper();
 //BA.debugLineNum = 44;BA.debugLine="Private Panel_profit As Panel";
mostCurrent._panel_profit = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private ListView_profit As ListView";
mostCurrent._listview_profit = new anywheresoftware.b4a.objects.ListViewWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Dim const cnt_default_ink_ml_index=0, cnt_default";
_cnt_default_ink_ml_index = (int) (0);
_cnt_default_ink_name_index = (int) (0);
_cnt_default_profit_name_index = (int) (0);
 //BA.debugLineNum = 48;BA.debugLine="Dim const cnt_int_ink_ml_array_size=5 As Int";
_cnt_int_ink_ml_array_size = (int) (5);
 //BA.debugLineNum = 49;BA.debugLine="Dim const cnt_int_ink_array_size=55 As Int";
_cnt_int_ink_array_size = (int) (55);
 //BA.debugLineNum = 50;BA.debugLine="Dim const cnt_int_profit_array_size=4 As Int";
_cnt_int_profit_array_size = (int) (4);
 //BA.debugLineNum = 52;BA.debugLine="Dim ary_str_ink_ml_name(cnt_int_ink_ml_array_size";
mostCurrent._ary_str_ink_ml_name = new String[_cnt_int_ink_ml_array_size];
java.util.Arrays.fill(mostCurrent._ary_str_ink_ml_name,"");
 //BA.debugLineNum = 53;BA.debugLine="Dim ary_int_ink_ml_value(cnt_int_ink_ml_array_siz";
_ary_int_ink_ml_value = new int[_cnt_int_ink_ml_array_size];
;
 //BA.debugLineNum = 54;BA.debugLine="Dim ary_str_ink_name(cnt_int_ink_array_size) As S";
mostCurrent._ary_str_ink_name = new String[_cnt_int_ink_array_size];
java.util.Arrays.fill(mostCurrent._ary_str_ink_name,"");
 //BA.debugLineNum = 55;BA.debugLine="Dim ary_str_ink_price(cnt_int_ink_array_size) As";
mostCurrent._ary_str_ink_price = new String[_cnt_int_ink_array_size];
java.util.Arrays.fill(mostCurrent._ary_str_ink_price,"");
 //BA.debugLineNum = 56;BA.debugLine="Dim ary_dbl_ink_value(cnt_int_ink_array_size) As";
_ary_dbl_ink_value = new double[_cnt_int_ink_array_size];
;
 //BA.debugLineNum = 57;BA.debugLine="Dim ary_str_profit_name(cnt_int_profit_array_size";
mostCurrent._ary_str_profit_name = new String[_cnt_int_profit_array_size];
java.util.Arrays.fill(mostCurrent._ary_str_profit_name,"");
 //BA.debugLineNum = 58;BA.debugLine="Dim ary_str_profit_unit(cnt_int_profit_array_size";
mostCurrent._ary_str_profit_unit = new String[_cnt_int_profit_array_size];
java.util.Arrays.fill(mostCurrent._ary_str_profit_unit,"");
 //BA.debugLineNum = 59;BA.debugLine="Dim ary_dbl_profit_value(cnt_int_profit_array_siz";
_ary_dbl_profit_value = new double[_cnt_int_profit_array_size];
;
 //BA.debugLineNum = 61;BA.debugLine="Dim int_select_ink_ml_index=0 As Int	'目前墨水容量選項";
_int_select_ink_ml_index = (int) (0);
 //BA.debugLineNum = 62;BA.debugLine="Dim int_select_ink_index=0 As Int		'目前墨水選項";
_int_select_ink_index = (int) (0);
 //BA.debugLineNum = 63;BA.debugLine="Dim int_select_profit_index=0 As Int	'目前利潤選項";
_int_select_profit_index = (int) (0);
 //BA.debugLineNum = 64;BA.debugLine="Dim int_bottle=0 As Int					'目前累積折讓空瓶數量";
_int_bottle = (int) (0);
 //BA.debugLineNum = 65;BA.debugLine="Dim int_cal_result=0 As Int				'計算結果";
_int_cal_result = (int) (0);
 //BA.debugLineNum = 66;BA.debugLine="Dim bol_main_menu_mode=True As Boolean	'主畫面狀態";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return "";
}
public static String  _listview_ink_itemclick(int _position,Object _value) throws Exception{
 //BA.debugLineNum = 396;BA.debugLine="Sub ListView_ink_ItemClick (Position As Int, Value";
 //BA.debugLineNum = 397;BA.debugLine="int_select_ink_index=Position";
_int_select_ink_index = _position;
 //BA.debugLineNum = 398;BA.debugLine="sub_update_menu";
_sub_update_menu();
 //BA.debugLineNum = 400;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 401;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 402;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 403;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 404;BA.debugLine="bol_main_menu_mode=True";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 405;BA.debugLine="End Sub";
return "";
}
public static String  _listview_ink_ml_itemclick(int _position,Object _value) throws Exception{
 //BA.debugLineNum = 385;BA.debugLine="Sub ListView_ink_ml_ItemClick (Position As Int, Va";
 //BA.debugLineNum = 386;BA.debugLine="int_select_ink_ml_index=Position";
_int_select_ink_ml_index = _position;
 //BA.debugLineNum = 387;BA.debugLine="sub_update_menu";
_sub_update_menu();
 //BA.debugLineNum = 389;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 390;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 391;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 392;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 393;BA.debugLine="bol_main_menu_mode=True";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 394;BA.debugLine="End Sub";
return "";
}
public static String  _listview_profit_itemclick(int _position,Object _value) throws Exception{
 //BA.debugLineNum = 407;BA.debugLine="Sub ListView_profit_ItemClick (Position As Int, Va";
 //BA.debugLineNum = 408;BA.debugLine="int_select_profit_index=Position";
_int_select_profit_index = _position;
 //BA.debugLineNum = 409;BA.debugLine="sub_update_menu";
_sub_update_menu();
 //BA.debugLineNum = 411;BA.debugLine="PanelMainMenu.Visible = True";
mostCurrent._panelmainmenu.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 412;BA.debugLine="Panel_ink_ml.Visible = False";
mostCurrent._panel_ink_ml.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 413;BA.debugLine="Panel_ink.Visible = False";
mostCurrent._panel_ink.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 414;BA.debugLine="Panel_profit.Visible = False";
mostCurrent._panel_profit.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 415;BA.debugLine="bol_main_menu_mode=True";
_bol_main_menu_mode = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 416;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
starter._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public static String  _sub_ink_menu_initial() throws Exception{
int _i = 0;
 //BA.debugLineNum = 301;BA.debugLine="Sub sub_ink_menu_initial";
 //BA.debugLineNum = 302;BA.debugLine="For i = 0 To (cnt_int_ink_array_size-1)";
{
final int step1 = 1;
final int limit1 = (int) ((_cnt_int_ink_array_size-1));
_i = (int) (0) ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
 //BA.debugLineNum = 303;BA.debugLine="ListView_ink.AddTwoLines2(ary_str_ink_name(i),ar";
mostCurrent._listview_ink.AddTwoLines2(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_name[_i]),BA.ObjectToCharSequence(mostCurrent._ary_str_ink_price[_i]),(Object)(_ary_dbl_ink_value[_i]));
 }
};
 //BA.debugLineNum = 305;BA.debugLine="End Sub";
return "";
}
public static String  _sub_ink_ml_menu_initial() throws Exception{
int _i = 0;
 //BA.debugLineNum = 294;BA.debugLine="Sub sub_ink_ml_menu_initial";
 //BA.debugLineNum = 295;BA.debugLine="For i = 0 To (cnt_int_ink_ml_array_size-1)";
{
final int step1 = 1;
final int limit1 = (int) ((_cnt_int_ink_ml_array_size-1));
_i = (int) (0) ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
 //BA.debugLineNum = 296;BA.debugLine="ListView_ink_ml.AddsingleLine2(ary_str_ink_ml_na";
mostCurrent._listview_ink_ml.AddSingleLine2(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_ml_name[_i]),(Object)(_ary_int_ink_ml_value[_i]));
 }
};
 //BA.debugLineNum = 298;BA.debugLine="End Sub";
return "";
}
public static String  _sub_profit_menu_initial() throws Exception{
int _i = 0;
 //BA.debugLineNum = 308;BA.debugLine="Sub sub_profit_menu_initial";
 //BA.debugLineNum = 309;BA.debugLine="For i = 0 To (cnt_int_profit_array_size-1)";
{
final int step1 = 1;
final int limit1 = (int) ((_cnt_int_profit_array_size-1));
_i = (int) (0) ;
for (;(step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1) ;_i = ((int)(0 + _i + step1))  ) {
 //BA.debugLineNum = 310;BA.debugLine="ListView_profit.AddTwoLines2(ary_str_profit_name";
mostCurrent._listview_profit.AddTwoLines2(BA.ObjectToCharSequence(mostCurrent._ary_str_profit_name[_i]),BA.ObjectToCharSequence(mostCurrent._ary_str_profit_unit[_i]),(Object)(_ary_dbl_profit_value[_i]));
 }
};
 //BA.debugLineNum = 312;BA.debugLine="End Sub";
return "";
}
public static String  _sub_update_menu() throws Exception{
 //BA.debugLineNum = 284;BA.debugLine="Sub sub_update_menu";
 //BA.debugLineNum = 285;BA.debugLine="Label_ink_ml.Text = ary_str_ink_ml_name(int_selec";
mostCurrent._label_ink_ml.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_ml_name[_int_select_ink_ml_index]));
 //BA.debugLineNum = 286;BA.debugLine="Label_ink_name.Text = ary_str_ink_name(int_select";
mostCurrent._label_ink_name.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_name[_int_select_ink_index]));
 //BA.debugLineNum = 287;BA.debugLine="Label_ink_price.Text = ary_str_ink_price(int_sele";
mostCurrent._label_ink_price.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_ink_price[_int_select_ink_index]));
 //BA.debugLineNum = 288;BA.debugLine="Label_profit_name.Text = ary_str_profit_name(int_";
mostCurrent._label_profit_name.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_profit_name[_int_select_profit_index]));
 //BA.debugLineNum = 289;BA.debugLine="Label_profit_unit.Text = ary_str_profit_unit(int_";
mostCurrent._label_profit_unit.setText(BA.ObjectToCharSequence(mostCurrent._ary_str_profit_unit[_int_select_profit_index]));
 //BA.debugLineNum = 290;BA.debugLine="EditTextResult.Text = int_cal_result";
mostCurrent._edittextresult.setText(BA.ObjectToCharSequence(_int_cal_result));
 //BA.debugLineNum = 291;BA.debugLine="End Sub";
return "";
}
}
